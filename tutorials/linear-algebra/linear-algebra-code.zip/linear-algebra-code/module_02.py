"""Linear Algebra, Module 2: Linear systems and elimination

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_02.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 2.3: A consistent system and an inconsistent one
from sympy import Matrix

for rows in ([[1, 1, 2], [2, 2, 4]], [[1, 1, 2], [2, 2, 5]]):
    reduced, pivots = Matrix(rows).rref()
    print(reduced.tolist(), pivots)
