"""Linear Algebra, Module 7: Orthogonality and QR

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_07.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 7.3: Check both properties
from sympy import Matrix

A = Matrix([[1, 1], [1, 0], [0, 1]])
Q, R = A.QRdecomposition()
print((Q.T * Q).tolist())
print(Q * R == A)
