"""Linear Algebra, Module 10: Symmetric matrices and quadratic forms

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_10.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 10.2: Eigenvalues and a quadratic form
from sympy import Matrix

A = Matrix([[2, 1], [1, 2]])
x = Matrix([1, -1])
print(sorted(A.eigenvals()))
print((x.T * A * x)[0])
