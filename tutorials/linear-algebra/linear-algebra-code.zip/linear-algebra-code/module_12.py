"""Linear Algebra, Module 12: Low-rank approximation and PCA

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_12.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 12.2: Centring, scoring and reconstructing
from sympy import Matrix, ones

data = Matrix([[13, 5], [7, 5], [10, 6], [10, 4]])
mean = ones(1, 4) * data / 4
X = data - ones(4, 1) * mean
v = Matrix([1, 0])
scores = X * v
reconstruction = scores * v.T + ones(4, 1) * mean
print(list(mean))
print(list(scores))
print(reconstruction.tolist())
print(sum(t**2 for t in data - reconstruction))


# %% Section 12.2: Find the component numerically
import numpy as np

data = np.array([[13., 5.], [7., 5.], [10., 6.], [10., 4.]])
mean = data.mean(axis=0)
X = data - mean
_, singular, vt = np.linalg.svd(X, full_matrices=False)
direction = vt[0]
scores = X @ direction
restored = scores[:, None] * direction + mean
explained = singular[0] ** 2 / np.dot(singular, singular)
print(f"first component explains {explained:.1%}")
print(f"squared reconstruction error = {np.sum((data - restored)**2):.0f}")
