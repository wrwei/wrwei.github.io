"""Linear Algebra, Module 11: Singular values and the pseudoinverse

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_11.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 11.3: Compare exact and minimum-norm fits
from sympy import Matrix

A = Matrix([[3, 0, 0], [0, 2, 0]])
b = Matrix([6, 8])
print(list(A.pinv() * b))
print((A * A.pinv() * b).tolist())
