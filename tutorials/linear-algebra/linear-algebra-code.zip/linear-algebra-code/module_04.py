"""Linear Algebra, Module 4: Subspaces, bases and dimension

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_04.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 4.3: Coordinates in a nonstandard basis
from sympy import Matrix

B = Matrix([[1, 1], [0, 1]])
v = Matrix([5, 2])
print(list(B.LUsolve(v)))
