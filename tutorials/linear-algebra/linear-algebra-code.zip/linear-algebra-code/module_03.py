"""Linear Algebra, Module 3: Matrices and linear maps

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_03.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 3.3: Compare the two products
from sympy import Matrix

scale = Matrix([[2, 0], [0, 1]])
shear = Matrix([[1, 1], [0, 1]])
print((scale * shear).tolist())
print((shear * scale).tolist())
