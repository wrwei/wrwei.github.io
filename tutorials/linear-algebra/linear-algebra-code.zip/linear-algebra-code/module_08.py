"""Linear Algebra, Module 8: Least squares and conditioning

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_08.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 8.2: Solve the line fit with QR
from sympy import Matrix

A = Matrix([[1, 0], [1, 1], [1, 2]])
b = Matrix([1, 2, 2])
Q, R = A.QRdecomposition()
x = R.upper_triangular_solve(Q.T * b)
print(list(x))
print(list(A.T * (b - A * x)))


# %% Section 8.2: Fit a line to floating-point data
import numpy as np

x_data = np.array([0., 1., 2.])
y_data = np.array([1., 2., 2.])
design = np.column_stack((np.ones(x_data.size), x_data))
coefficients, _, rank, _ = np.linalg.lstsq(design, y_data, rcond=None)
residual = y_data - design @ coefficients
print(f"intercept={coefficients[0]:.3f}, slope={coefficients[1]:.3f}")
print(f"rank={rank}, residual norm={np.linalg.norm(residual):.3f}")
