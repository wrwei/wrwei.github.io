"""Linear Algebra, Module 1: Vectors and dot products

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_01.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 1.2: Exact vector arithmetic
from sympy import Matrix

v = Matrix([3, 4])
print(v.norm())
print(list(v / v.norm()))
