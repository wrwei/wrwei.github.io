"""Linear Algebra, Module 9: Eigenvalues and diagonalisation

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_09.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 9.2: A repeated eigenvalue with a missing direction
from sympy import Matrix

A = Matrix([[1, 1], [0, 1]])
for value, multiplicity, basis in A.eigenvects():
    print(value, multiplicity, [list(v) for v in basis])
print((A**4).tolist())
