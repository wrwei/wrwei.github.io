"""Linear Algebra, Module 6: Determinants, inverses and LU

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_06.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 6.3: Verify a factorisation and solve
from sympy import Matrix

A = Matrix([[2, 1], [4, 3]])
L, U, swaps = A.LUdecomposition()
print(L.tolist(), U.tolist(), swaps)
print(list(A.LUsolve(Matrix([5, 11]))))
