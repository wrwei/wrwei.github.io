"""Linear Algebra, Module 5: Rank, nullity and the four subspaces

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_05.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 5.3: Bases in exact arithmetic
from sympy import Matrix

A = Matrix([[1, 2, 3], [2, 4, 6]])
print(A.rank())
print([list(v) for v in A.nullspace()])
print([list(v) for v in A.T.nullspace()])
