"""Maths for AI and LLMs, Module 7: Floating-point arithmetic and stable softmax

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_07.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 7.2: Compute in shifted coordinates
from math import exp, fsum, log

for logits, target in [([1000.0, 1001.0], 1), ([0.0, -1000.0], 1)]:
    largest = max(logits)
    shifted = [value - largest for value in logits]
    log_normalizer = log(fsum(exp(value) for value in shifted))
    print(f"{shifted[target] - log_normalizer:.4f}")
