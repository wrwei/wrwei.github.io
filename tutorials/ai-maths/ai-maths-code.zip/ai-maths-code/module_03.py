"""Maths for AI and LLMs, Module 3: Entropy, cross-entropy and KL divergence

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_03.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 3.2: Average surprise
from math import log

p, q = (0.75, 0.25), (0.5, 0.5)
entropy = -sum(pi * log(pi) for pi in p if pi > 0)
cross_entropy = -sum(pi * log(qi) for pi, qi in zip(p, q) if pi > 0)
print(f"{entropy:.4f} {cross_entropy:.4f} {cross_entropy - entropy:.4f}")
