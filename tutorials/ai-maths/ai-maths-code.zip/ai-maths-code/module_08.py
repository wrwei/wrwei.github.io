"""Maths for AI and LLMs, Module 8: Quantisation and measuring numerical error

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_08.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 8.2: Compare exact rational reference values
from fractions import Fraction as F

weights = [F(3, 10), F(-11, 20), F(1, 5)]
inputs = [2, -1, 4]
scale, limit = F(1, 4), 3
codes = [max(-limit, min(limit, round(w / scale))) for w in weights]
reference = sum(x * w for x, w in zip(inputs, weights))
approximation = sum(x * q * scale for x, q in zip(inputs, codes))
print(codes)
print(reference, approximation, abs(reference - approximation))
print(scale * sum(map(abs, inputs)) / 2)
