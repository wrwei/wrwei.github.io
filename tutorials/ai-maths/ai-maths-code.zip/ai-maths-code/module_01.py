"""Maths for AI and LLMs, Module 1: Conditional probability and token sequences

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_01.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 1.3: Follow one path
from fractions import Fraction
from math import prod

factors = [Fraction(3, 5), Fraction(1, 4), Fraction(2, 3)]
print(prod(factors[:2]))
print(prod(factors))
