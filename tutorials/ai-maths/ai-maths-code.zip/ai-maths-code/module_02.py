"""Maths for AI and LLMs, Module 2: Estimation and held-out evaluation

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_02.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 2.2: Inspect a held-out mean
from math import sqrt
from statistics import mean, stdev

scores = [0.6, 0.8, 1.0, 0.8]
print(f"{mean(scores):.3f}")
print(f"{stdev(scores) / sqrt(len(scores)):.3f}")
