"""Maths for AI and LLMs, Module 4: Next-token loss, perplexity and sampling

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_04.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 4.2: Compare two temperatures
from math import exp, log

gap = log(3)
for temperature in (1.0, 0.5):
    print(f"{exp(gap / temperature):.0f}")
