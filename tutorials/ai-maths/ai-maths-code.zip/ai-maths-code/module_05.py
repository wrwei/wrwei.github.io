"""Maths for AI and LLMs, Module 5: Gradients and learning rates

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_05.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 5.2: Observe contraction and overshoot
for rate in (0.375, 0.625):
    error = 1.0
    for _ in range(3):
        error *= 1 - 4 * rate
    print(f"{error:.3f}")
