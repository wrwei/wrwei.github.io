"""Maths for AI and LLMs, Module 6: Mini-batches, Adam and regularisation

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_06.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 6.2: The first step
from math import sqrt

rate, eps = 0.1, 1e-8
for gradient in (2.0, -6.0):
    first = 0.1 * gradient / (1 - 0.9)
    second = 0.001 * gradient**2 / (1 - 0.999)
    update = -rate * first / (sqrt(second) + eps)
    print(f"{update:.3f}")
