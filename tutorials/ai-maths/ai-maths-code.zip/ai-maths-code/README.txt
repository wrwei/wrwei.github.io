Maths for AI and LLMs / AI 与大语言模型的数学基础

Run an example with python module_01.py.
The examples use the Python standard library.

用 python module_01.py 运行一个示例。
示例仅使用 Python 标准库。
