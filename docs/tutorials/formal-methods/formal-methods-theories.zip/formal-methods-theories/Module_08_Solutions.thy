theory Module_08_Solutions
  imports Module_08
begin

term "[Some True, None]"
term "(Suc, [0::nat])"
term "\<lambda>xs. Red # xs"
term "map next_light"
term "\<lambda>f x. f (f x)"

value "take 3 (drop 2 [0..<10])"
value "zip [Red, Green] [1, 2, 3::nat]"
value "filter (\<lambda>n. n mod 3 = 0) [0..<10]"
value "foldr (\<lambda>x xs. xs @ [x]) [1, 2, 3::nat] []"
value "[n * n. n \<leftarrow> [1..<5]]"

value "(5::nat) - 7 + 7"
value "(5::int) - 7 + 7"
value "(7::nat) div 2 * 2"
value "(-7::int) div 2"
value "(-7::int) mod 2"
value "(7::nat) mod 0"

value "map (\<lambda>l. safe (l, cross l)) [Red, RedAmber, Green, Amber]"

definition safe_cycle :: "(light \<times> light) list" where
  "safe_cycle = [(Green, Red), (Amber, Red), (Red, Red), (Red, RedAmber),
                 (Red, Green), (Red, Amber), (Red, Red), (RedAmber, Red)]"

value "filter (\<lambda>p. \<not> safe p) safe_cycle"

primrec from_list :: "'a list \<Rightarrow> 'a stack" where
  "from_list [] = Empty"
| "from_list (x # xs) = Push x (from_list xs)"

value "from_list [Red, Green]"

lemma "to_list (from_list xs) = xs"
  by (induction xs) auto

lemma "height (from_list xs) = length xs"
  by (induction xs) auto

definition average :: "nat list \<Rightarrow> nat" where
  "average xs = sum_list xs div length xs"

value "average (map duration (trace 4 Red))"
value "average []"

lemma "average [] = 0"
  by (simp add: average_def)

lemma "average [n] = n"
  by (simp add: average_def)

fun code_of :: "light \<Rightarrow> nat" where
  "code_of Red = 0"
| "code_of RedAmber = 1"
| "code_of Green = 2"
| "code_of Amber = 3"

fun light_of :: "nat \<Rightarrow> light option" where
  "light_of 0 = Some Red"
| "light_of (Suc 0) = Some RedAmber"
| "light_of (Suc (Suc 0)) = Some Green"
| "light_of (Suc (Suc (Suc 0))) = Some Amber"
| "light_of n = None"

thm light_of.simps

value "map light_of [0, 2, 7]"

lemma "light_of (code_of l) = Some l"
  by (cases l) (simp_all add: numeral_eq_Suc)

fun merge :: "'a::linorder list \<Rightarrow> 'a list \<Rightarrow> 'a list" where
  "merge [] ys = ys"
| "merge xs [] = xs"
| "merge (x # xs) (y # ys) =
     (if x \<le> y then x # merge xs (y # ys) else y # merge (x # xs) ys)"

value "merge [1, 4, 6] [2, 3, 7::nat]"

function count_up :: "nat \<Rightarrow> nat \<Rightarrow> nat" where
  "count_up i n = (if i < n then count_up (i + 1) n + 1 else 0)"
  by pat_completeness auto
termination
  by (relation "measure (\<lambda>(i, n). n - i)") auto

value "count_up 3 10"

end
