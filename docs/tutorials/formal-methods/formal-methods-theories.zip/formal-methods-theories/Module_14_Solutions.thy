theory Module_14_Solutions
  imports Module_14
begin

value "compile (Add (Add (Var ''x'') (Num 1)) (Var ''y''))"

value "exec (compile (Add (Add (Var ''x'') (Num 1)) (Var ''y''))) s0 []"

lemma "length (exec (compile e) s stk) = length stk + 1"
  by (simp add: compile_correct)

lemma "exec (compile e @ compile e) s stk = eval e s # eval e s # stk"
  by (simp add: compile_correct)

lemma length_fold_add:
  "length (compile (fold_add a b))
   \<le> length (compile a) + length (compile b) + 1"
  by (induction a b rule: fold_add.induct) auto

theorem cfold_shorter:
  "length (compile (cfold e)) \<le> length (compile e)"
proof (induction e)
  case (Add a b)
  have "length (compile (cfold (Add a b)))
        \<le> length (compile (cfold a)) + length (compile (cfold b)) + 1"
    using length_fold_add by simp
  also have "\<dots> \<le> length (compile (Add a b))"
    using Add.IH by simp
  finally show ?case .
qed simp_all

lemma "eval (fold_add_bad a b) s = eval a s + eval b s"
  quickcheck
  oops

fun fold_add0 :: "expr \<Rightarrow> expr \<Rightarrow> expr" where
  "fold_add0 (Num m) (Num n) = Num (m + n)"
| "fold_add0 a b =
     (if a = Num 0 then b else if b = Num 0 then a else Add a b)"

lemma "eval (fold_add0 a b) s = eval a s + eval b s"
  by (induction a b rule: fold_add0.induct) auto

fun subst :: "vname \<Rightarrow> int \<Rightarrow> expr \<Rightarrow> expr" where
  "subst x n (Num m) = Num m"
| "subst x n (Var y) = (if y = x then Num n else Var y)"
| "subst x n (Add a b) = Add (subst x n a) (subst x n b)"

value "subst ''x'' 3 (Add (Var ''x'') (Add (Var ''y'') (Var ''x'')))"

lemma eval_subst: "eval (subst x n e) s = eval e (s(x := n))"
  by (induction e) auto

lemma compile_cont:
  "exec (compile e @ c) s stk = exec c s (eval e s # stk)"
  by (induction e arbitrary: c stk) (auto simp del: exec_append)

lemma "exec (compile e) s stk = eval e s # stk"
  using compile_cont [of e "[]"] by simp

fun exec1_opt :: "instr \<Rightarrow> state \<Rightarrow> stack \<Rightarrow> stack option" where
  "exec1_opt (PUSH n) s stk = Some (n # stk)"
| "exec1_opt (LOAD x) s stk = Some (s x # stk)"
| "exec1_opt ADD s (j # i # stk) = Some ((i + j) # stk)"
| "exec1_opt ADD s stk = None"

fun exec_opt :: "instr list \<Rightarrow> state \<Rightarrow> stack \<Rightarrow> stack option" where
  "exec_opt [] s stk = Some stk"
| "exec_opt (i # c) s stk =
     (case exec1_opt i s stk of
        None \<Rightarrow> None
      | Some stk' \<Rightarrow> exec_opt c s stk')"

value "(exec_opt [PUSH 1, ADD] s0 [], exec_opt (compile sample) s0 [])"

lemma exec_opt_cont:
  "exec_opt (compile e @ c) s stk = exec_opt c s (eval e s # stk)"
  by (induction e arbitrary: c stk) auto

theorem exec_opt_compile:
  "exec_opt (compile e) s stk = Some (eval e s # stk)"
  using exec_opt_cont [of e "[]"] by simp

fun rexec1 :: "rinstr \<Rightarrow> state \<Rightarrow> regs \<Rightarrow> regs" where
  "rexec1 (LDI r n) s rs = rs(r := n)"
| "rexec1 (LDV r x) s rs = rs(r := s x)"
| "rexec1 (ADDR r q) s rs = rs(r := rs r + rs q)"

fun rexec :: "rinstr list \<Rightarrow> state \<Rightarrow> regs \<Rightarrow> regs" where
  "rexec [] s rs = rs"
| "rexec (i # c) s rs = rexec c s (rexec1 i s rs)"

lemma rexec_append [simp]:
  "rexec (c1 @ c2) s rs = rexec c2 s (rexec c1 s rs)"
  by (induction c1 arbitrary: rs) auto

fun rcompile :: "expr \<Rightarrow> nat \<Rightarrow> rinstr list" where
  "rcompile (Num n) r = [LDI r n]"
| "rcompile (Var x) r = [LDV r x]"
| "rcompile (Add a b) r =
     rcompile a r @ rcompile b (r + 1) @ [ADDR r (r + 1)]"

value "rcompile sample 0"

theorem rcompile_correct:
  "rexec (rcompile e r) s rs r = eval e s \<and>
   (\<forall>q < r. rexec (rcompile e r) s rs q = rs q)"
  by (induction e arbitrary: r rs) auto

lemma "rexec (rcompile e r) s rs r = eval e s"
  apply (induction e arbitrary: r rs)
  apply auto

  oops

end
