theory Module_11
  imports Main
begin

fun sumacc :: "nat list \<Rightarrow> nat \<Rightarrow> nat" where
  "sumacc [] acc = acc"
| "sumacc (x # xs) acc = sumacc xs (acc + x)"

value "sumacc [3, 1, 4] 0"

lemma "sumacc xs 0 = sum_list xs"
  apply (induction xs)

  apply auto

  oops

lemma "sumacc xs acc = sum_list xs"
  quickcheck
  oops

lemma "sumacc xs acc = acc + sum_list xs"
  apply (induction xs)
  apply auto

  oops

lemma "sumacc xs acc = acc + sum_list xs"
  apply (induction xs arbitrary: acc)

  apply auto
  done

lemma sumacc_sum: "sumacc xs acc = acc + sum_list xs"
proof (induction xs arbitrary: acc)
  case Nil
  show ?case by simp
next
  case (Cons x xs)
  have "sumacc (x # xs) acc = sumacc xs (acc + x)" by simp
  also have "\<dots> = (acc + x) + sum_list xs" by (rule Cons.IH)
  also have "\<dots> = acc + sum_list (x # xs)" by simp
  finally show ?case .
qed

lemma sumacc_total: "sumacc xs 0 = sum_list xs"
  by (simp add: sumacc_sum)

fun oddsum :: "nat \<Rightarrow> nat" where
  "oddsum 0 = 0"
| "oddsum (Suc n) = oddsum n + (2 * n + 1)"

value "oddsum 4"

lemma "\<exists>k. oddsum n = k * k"
  apply (induction n)
  apply auto

  oops

lemma oddsum_square: "oddsum n = n * n"
  by (induction n) auto

lemma "\<exists>k. oddsum n = k * k"
  using oddsum_square by blast

fun val :: "bool list \<Rightarrow> nat" where
  "val [] = 0"
| "val (b # bs) = (if b then 1 else 0) + 2 * val bs"

fun inc :: "bool list \<Rightarrow> bool list" where
  "inc [] = [True]"
| "inc (b # bs) = (if b then False # inc bs else True # bs)"

fun counter :: "nat \<Rightarrow> bool list" where
  "counter 0 = []"
| "counter (Suc n) = inc (counter n)"

value "counter 6"

lemma "val (counter n) = n"
  apply (induction n)
  apply auto

  oops

value "val (inc [True, True, False])"

lemma "val (inc bs) = Suc (val bs)"
  quickcheck
  oops

lemma val_inc [simp]: "val (inc bs) = Suc (val bs)"
  by (induction bs) auto

lemma val_counter: "val (counter n) = n"
  by (induction n) auto

find_theorems "rev (_ @ _)"

datatype 'a btree = Lf | Nd "'a btree" 'a "'a btree"

fun nodes :: "'a btree \<Rightarrow> nat" where
  "nodes Lf = 0"
| "nodes (Nd l x r) = nodes l + 1 + nodes r"

fun height :: "'a btree \<Rightarrow> nat" where
  "height Lf = 0"
| "height (Nd l x r) = max (height l) (height r) + 1"

fun mirror :: "'a btree \<Rightarrow> 'a btree" where
  "mirror Lf = Lf"
| "mirror (Nd l x r) = Nd (mirror r) x (mirror l)"

fun inorder :: "'a btree \<Rightarrow> 'a list" where
  "inorder Lf = []"
| "inorder (Nd l x r) = inorder l @ [x] @ inorder r"

value "inorder (mirror (Nd (Nd Lf 1 Lf) (2::nat) (Nd Lf 3 Lf)))"

lemma "inorder (mirror t) = rev (inorder t)"
  apply (induction t)

  apply auto
  done

lemma "nodes t < 2 ^ height t"
  apply (induction t)
  apply auto

  oops

lemma nodes_height: "nodes t < 2 ^ height t"
proof (induction t)
  case Lf
  show ?case by simp
next
  case (Nd l x r)
  let ?h = "max (height l) (height r)"
  have "(2::nat) ^ height l \<le> 2 ^ ?h" by simp
  with Nd.IH(1) have l: "nodes l < 2 ^ ?h" by linarith
  have "(2::nat) ^ height r \<le> 2 ^ ?h" by simp
  with Nd.IH(2) have r: "nodes r < 2 ^ ?h" by linarith
  have "nodes (Nd l x r) = nodes l + 1 + nodes r" by simp
  also have "\<dots> < 2 ^ ?h + 2 ^ ?h" using l r by linarith
  also have "\<dots> = 2 ^ height (Nd l x r)" by simp
  finally show ?case .
qed

fun fib :: "nat \<Rightarrow> nat" where
  "fib 0 = 0"
| "fib (Suc 0) = 1"
| "fib (Suc (Suc n)) = fib n + fib (Suc n)"

lemma "fib n < 2 ^ n"
  apply (induction n rule: fib.induct)

  apply auto
  done

fun merge :: "nat list \<Rightarrow> nat list \<Rightarrow> nat list" where
  "merge [] ys = ys"
| "merge xs [] = xs"
| "merge (x # xs) (y # ys) =
     (if x \<le> y then x # merge xs (y # ys) else y # merge (x # xs) ys)"

value "merge [1, 4, 6] [2, 3, 7]"

lemma "length (merge xs ys) = length xs + length ys"
  apply (induction xs arbitrary: ys)
  apply auto

  oops

thm merge.induct

thm merge.simps

lemma "length (merge xs ys) = length xs + length ys"
  apply (induction xs ys rule: merge.induct)

  apply auto
  done

lemma set_merge: "set (merge xs ys) = set xs \<union> set ys"
proof (induction xs ys rule: merge.induct)
  case (1 ys)
  show ?case by simp
next
  case (2 x xs)
  show ?case by simp
next
  case (3 x xs y ys)
  show ?case
  proof (cases "x \<le> y")
    case True
    then show ?thesis using "3.IH"(1) by auto
  next
    case False
    then show ?thesis using "3.IH"(2) by auto
  qed
qed

inductive ev :: "nat \<Rightarrow> bool" where
  ev_0: "ev 0"
| ev_SS: "ev n \<Longrightarrow> ev (Suc (Suc n))"

thm ev.intros

lemma "ev (Suc (Suc (Suc (Suc 0))))"
  apply (rule ev_SS)

  apply (rule ev_SS)
  apply (rule ev_0)
  done

lemma "ev 4"
  by (simp add: ev.intros numeral_eq_Suc)

thm ev.induct

lemma "ev n \<Longrightarrow> even n"
  apply (induction rule: ev.induct)

  apply auto
  done

lemma ev_even: "ev n \<Longrightarrow> even n"
proof (induction rule: ev.induct)
  case ev_0
  show ?case by simp
next
  case (ev_SS n)
  from ev_SS.IH show ?case by simp
qed

lemma ev_add: "ev m \<Longrightarrow> ev n \<Longrightarrow> ev (m + n)"
proof (induction rule: ev.induct)
  case ev_0
  then show ?case by simp
next
  case (ev_SS k)
  then have "ev (k + n)" by simp
  then show ?case by (simp add: ev.ev_SS)
qed

inductive_cases ev_SSE: "ev (Suc (Suc n))"
inductive_cases ev_1E: "ev (Suc 0)"

lemma "\<not> ev (Suc (Suc (Suc 0)))"
  by (auto elim: ev_SSE ev_1E)

lemma ev_SS_inv: "ev (Suc (Suc n)) \<Longrightarrow> ev n"
proof -
  assume "ev (Suc (Suc n))"
  then show "ev n"
  proof cases
    case ev_SS
    then show ?thesis by simp
  qed
qed

lemma "\<not> ev (Suc 0)"
proof
  assume "ev (Suc 0)"
  then show False by cases
qed

inductive steps :: "('a \<Rightarrow> 'a \<Rightarrow> bool) \<Rightarrow> 'a \<Rightarrow> 'a \<Rightarrow> bool" for r where
  stay: "steps r a a"
| step: "r a b \<Longrightarrow> steps r b c \<Longrightarrow> steps r a c"

datatype status = Todo | Doing | Review | Done

inductive move :: "status \<Rightarrow> status \<Rightarrow> bool" where
  "move Todo Doing"
| "move Doing Review"
| "move Review Doing"
| "move Review Done"

lemma "steps move Todo Done"
  by (blast intro: move.intros step stay)

lemma steps_trans: "steps r a b \<Longrightarrow> steps r b c \<Longrightarrow> steps r a c"
  apply (induction rule: steps.induct)

  apply (auto intro: step)
  done

lemma "steps move Done s \<Longrightarrow> s = Done"
  apply (induction rule: steps.induct)

  oops

lemma done_stays: "steps move a s \<Longrightarrow> a = Done \<Longrightarrow> s = Done"
  by (induction rule: steps.induct) (auto elim: move.cases)

lemma "steps move Done s \<Longrightarrow> s = Done"
  apply (induction Done s rule: steps.induct)

  apply (auto elim: move.cases)
  done

datatype paren = LP | RP

inductive bal :: "paren list \<Rightarrow> bool" where
  bal_nil: "bal []"
| bal_wrap: "bal w \<Longrightarrow> bal (LP # w @ [RP])"
| bal_cat: "bal v \<Longrightarrow> bal w \<Longrightarrow> bal (v @ w)"

fun chk :: "paren list \<Rightarrow> nat \<Rightarrow> bool" where
  "chk [] n = (n = 0)"
| "chk (LP # w) n = chk w (Suc n)"
| "chk (RP # w) 0 = False"
| "chk (RP # w) (Suc n) = chk w n"

value "chk [LP, LP, RP, RP, LP, RP] 0"

value "chk [RP, LP] 0"

lemma "bal w \<Longrightarrow> chk w 0"
  apply (induction rule: bal.induct)
  apply auto

  oops

lemma bal_chk: "bal w \<Longrightarrow> chk (w @ v) n = chk v n"
  apply (induction arbitrary: v n rule: bal.induct)

  apply auto
  done

corollary bal_chk0: "bal w \<Longrightarrow> chk w 0"
  using bal_chk[of w "[]" 0] by simp

thm less_induct

lemma "0 < (n::nat) \<Longrightarrow> \<exists>k m. n = 2 ^ k * m \<and> odd m"
  apply (induction n rule: less_induct)

  oops

lemma odd_part: "0 < (n::nat) \<Longrightarrow> \<exists>k m. n = 2 ^ k * m \<and> odd m"
proof (induction n rule: less_induct)
  case (less n)
  show ?case
  proof (cases "even n")
    case False
    then have "n = 2 ^ 0 * n \<and> odd n" by simp
    then show ?thesis by blast
  next
    case True
    then obtain h where h: "n = 2 * h" by (rule evenE)
    with less.prems have "h < n" and "0 < h" by simp_all
    then obtain k m where "h = 2 ^ k * m \<and> odd m" using less.IH by blast
    with h have "n = 2 ^ Suc k * m \<and> odd m" by simp
    then show ?thesis by blast
  qed
qed

fun itrev :: "'a list \<Rightarrow> 'a list \<Rightarrow> 'a list" where
  "itrev [] ys = ys"
| "itrev (x # xs) ys = itrev xs (x # ys)"

lemma "itrev xs [] = rev xs"
  apply (induction xs)
  apply auto

  oops

end
