theory Module_04_Solutions
  imports Module_04
begin

value "{1, 2, 3, 4} - {3, 4, 5 :: nat}"
value "{3, 4, 5} - {1, 2, 3, 4 :: nat}"
value "{1, 2, 3, 4} \<inter> {3, 4, 5} \<inter> {1, 5 :: nat}"
value "{1, 5 :: nat} \<times> {0, 1 :: nat}"
value "Pow {1, 5 :: nat}"

lemma "A - (B \<union> C) = (A - B) \<inter> (A - C)"
  by auto

lemma "(A \<union> B) - C = A \<union> (B - C)"
  nitpick [card 'a = 1]
  oops

definition calls :: "(string \<times> string) set" where
  "calls = {(''main'', ''parse''), (''main'', ''eval''), (''parse'', ''lex''),
            (''eval'', ''apply''), (''apply'', ''eval'')}"

value "calls\<^sup>+ `` {''main''}"
value "(''apply'', ''apply'') \<in> calls\<^sup>+"
value "(''main'', ''main'') \<in> calls\<^sup>+"

value "bij_betw (\<lambda>n::nat. 3 * n mod 4) {0, 1, 2, 3} {0, 1, 2, 3}"

lemma "equiv A R \<longrightarrow> equiv A S \<longrightarrow> equiv A (R \<inter> S)"
  by (auto simp: equiv_def refl_on_def sym_Int trans_Int)

value "trans_on {1, 2, 3}
         ({(1::nat, 1), (2, 2), (3, 3), (1, 2), (2, 1)} \<union> {(1, 1), (2, 2), (3, 3), (2, 3), (3, 2)})"

lemma "(\<lambda>n. \<not> f n n) \<notin> range (f :: nat \<Rightarrow> nat \<Rightarrow> bool)"
  by (auto simp: fun_eq_iff)

end
