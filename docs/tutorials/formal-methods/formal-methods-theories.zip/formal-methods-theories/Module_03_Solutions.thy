theory Module_03_Solutions
  imports Module_03
begin

lemma "(\<exists>x. P x \<and> Q x) \<longrightarrow> (\<exists>x. P x) \<and> (\<exists>x. Q x)"
  by blast

lemma "(\<forall>x. P x \<longrightarrow> Q x) \<longrightarrow> (\<exists>x. P x) \<longrightarrow> (\<exists>x. Q x)"
  by blast

lemma "(\<exists>x. P x) \<and> (\<exists>x. Q x) \<longrightarrow> (\<exists>x. P x \<and> Q x)"
  nitpick [card = 2]

  oops

lemma "(\<forall>x. \<exists>y. R x y) \<longrightarrow> (\<forall>x. \<exists>y. R y x)"
  nitpick [card = 2]

  oops

lemma "\<not> (\<forall>x y. P x \<and> P y \<longrightarrow> x = y) \<longleftrightarrow>
       (\<exists>x y. x \<noteq> y \<and> P x \<and> P y)"
  by blast

lemma "(\<exists>x. \<forall>y. P y \<longrightarrow> y = x) \<longleftrightarrow> (\<exists>!x. P x)"
  nitpick [card 'a = 1]

  oops

consts
  can_read :: "user \<Rightarrow> doc \<Rightarrow> bool"
  bob :: user

lemma "(\<forall>u d. can_delete u d \<longrightarrow> can_read u d) \<and>
       (\<forall>u d. owns u d \<longrightarrow> can_delete u d) \<and>
       owns alice report \<longrightarrow> can_read alice report"
  by blast

lemma "(\<forall>u d. can_delete u d \<longrightarrow> can_read u d) \<and>
       (\<forall>u d. owns u d \<longrightarrow> can_delete u d) \<and>
       admin bob \<longrightarrow> can_read bob report"
  nitpick [card user = 1, card doc = 1, show_consts]

  oops

end
