theory Module_04
  imports Main
begin

value "{1, 2, 3} \<union> {3, 4 :: nat}"

value "{x \<in> {0..10}. x mod 3 = (0::nat)}"

value "Pow {1, 2, 3 :: nat}"

lemma "A \<inter> (B \<union> C) = A \<inter> B \<union> A \<inter> C"

  by auto

lemma "- (A \<union> B) = - A \<inter> - B"
  by auto

lemma "x \<in> {y. P y} \<longleftrightarrow> P x"
  by simp

lemma "A - (B - C) = (A - B) - (C :: 'a set)"
  nitpick [card 'a = 1]
  oops

lemma "A - (B - C) = A - B - C"
  nitpick [card 'a = 2]
  oops

value "{1, 2 :: nat} \<times> {''x'', ''y''}"

value "refl_on {1, 2, 3} {(1::nat, 1), (2, 2), (1, 2)}"
value "trans_on {1, 2, 3} {(1::nat, 2), (2, 3)}"
value "trans_on {1, 2, 3} {(1::nat, 2), (2, 3), (1, 3)}"

value "{(''alice'', ''admin''), (''bob'', ''guest'')}
     O {(''admin'', ''read''), (''admin'', ''write''), (''guest'', ''read'')}"

lemma "trans r \<longleftrightarrow> r O r \<subseteq> r"
  by (auto simp: trans_def)

lemma "sym r \<longleftrightarrow> r\<inverse> = r"
  by (auto simp: sym_def)

lemma "(r O s)\<inverse> = s\<inverse> O r\<inverse>"
  by auto

value "{(x, y) \<in> {0..8::nat} \<times> {0..8}. x mod 3 = y mod 3} `` {4}"

value "{0..8::nat} // {(x, y) \<in> {0..8} \<times> {0..8}. x mod 3 = y mod 3}"

lemma "equiv UNIV {(x, y). x mod 3 = (y::nat) mod 3}"
  by (auto simp: equiv_def refl_on_def sym_def trans_def)

lemma "equiv A r \<longrightarrow> X \<in> A // r \<longrightarrow> Y \<in> A // r \<longrightarrow> X = Y \<or> X \<inter> Y = {}"
  by (simp add: quotient_disj)

lemma "wf {(x, y). x < (y::nat)}"
  by (simp add: wf_less)

thm wf_iff_no_infinite_down_chain

value "{1::nat} \<subseteq> {2} \<or> {2} \<subseteq> {1::nat}"

definition door :: "(string \<times> string) set" where
  "door = {(''CL'', ''CU''), (''CU'', ''CL''), (''CU'', ''OU''), (''OU'', ''CU'')}"

value "door\<^sup>* `` {''CL''}"

value "''OL'' \<in> door\<^sup>* `` {''CL''}"
value "''OL'' \<in> (door \<union> {(''OU'', ''OL'')})\<^sup>* `` {''CL''}"

value "{(1::nat, 2), (2, 3), (3, 4)}\<^sup>+"

lemma "r \<subseteq> r\<^sup>+"
  by auto

lemma "trans (r\<^sup>+)"
  by simp

lemma "(r\<^sup>*)\<^sup>* = r\<^sup>*"
  by simp

lemma "inj (\<lambda>n::nat. 2 * n)"

  by (auto simp: inj_def)

lemma "\<not> surj (\<lambda>n::nat. n + 1)"
  by (auto simp: surj_def)

lemma "bij (\<lambda>n::int. n + 1)"
  by (auto simp: bij_def inj_def surj_def)

lemma "inj f \<longrightarrow> inj g \<longrightarrow> inj (g \<circ> f)"
  by (auto simp: inj_def)

lemma "inj f \<longrightarrow> inv f (f x) = x"
  by simp

value "bij_betw (\<lambda>x::nat. (x + 1) mod 3) {0, 1, 2} {0, 1, 2}"

value "card {1, 2, 3, 2, 1 :: nat}"
value "card (Pow {1, 2, 3 :: nat})"

value "inj_on (\<lambda>n::nat. n mod 12) {0..12}"

lemma "finite A \<longrightarrow> card (Pow A) = 2 ^ card A"
  by (simp add: card_Pow)

lemma "card (f ` A) < card A \<longrightarrow> \<not> inj_on f A"
  by (simp add: pigeonhole)

lemma "card (UNIV :: nat set) = 0"
  by simp

lemma diagonal: "{x. x \<notin> f x} \<notin> range f"
  by auto

lemma cantor: "\<not> surj (f :: 'a \<Rightarrow> 'a set)"
  by force

lemma "\<not> surj (f :: nat \<Rightarrow> nat set)"
  by (simp add: cantor)

thm Cantors_theorem

end
