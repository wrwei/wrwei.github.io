theory Module_11_Solutions
  imports Module_11
begin

lemma itrev_rev: "itrev xs ys = rev xs @ ys"
  by (induction xs arbitrary: ys) auto

lemma "itrev xs [] = rev xs"
  by (simp add: itrev_rev)

lemma "nodes (mirror t) = nodes t"
  by (induction t) auto

lemma "steps r a b \<Longrightarrow> r b c \<Longrightarrow> steps r a c"
  by (induction rule: steps.induct) (auto intro: step stay)

lemma "count_list (merge xs ys) z = count_list xs z + count_list ys z"
  by (induction xs ys rule: merge.induct) auto

lemma "sumacc (xs @ ys) acc = sumacc ys (sumacc xs acc)"
  by (induction xs arbitrary: acc) auto

lemma "ev n \<Longrightarrow> \<not> ev (Suc n)"
  by (induction rule: ev.induct) (auto elim: ev_SSE ev_1E)

lemma "0 < n \<Longrightarrow> (n::nat) div 2 < n"
  by simp

fun flat :: "'a btree \<Rightarrow> 'a list \<Rightarrow> 'a list" where
  "flat Lf acc = acc"
| "flat (Nd l x r) acc = flat l (x # flat r acc)"

lemma flat_inorder: "flat t acc = inorder t @ acc"
  by (induction t arbitrary: acc) auto

lemma "flat t [] = inorder t"
  by (simp add: flat_inorder)

lemma ev_double: "ev (n + n)"
proof (induction n)
  case 0
  show ?case by (simp add: ev_0)
next
  case (Suc n)
  then show ?case by (simp add: ev_SS)
qed

lemma "ev m \<Longrightarrow> ev (m * n)"
proof (induction n)
  case 0
  show ?case by (simp add: ev_0)
next
  case (Suc n)
  then have "ev (m * n)" by simp
  with Suc.prems have "ev (m + m * n)" by (rule ev_add)
  then show ?case by simp
qed

lemma "\<not> bal [RP, LP]"
proof
  assume "bal [RP, LP]"
  then have "chk [RP, LP] 0" by (rule bal_chk0)
  then show False by simp
qed

lemma "\<not> bal [LP]"
proof
  assume "bal [LP]"
  then have "chk [LP] 0" by (rule bal_chk0)
  then show False by simp
qed

lemma "fib n < 2 ^ n"
proof (induction n rule: less_induct)
  case (less n)
  show ?case
  proof (cases n rule: fib.cases)
    case 1
    then show ?thesis by simp
  next
    case 2
    then show ?thesis by simp
  next
    case (3 k)
    have "fib k < 2 ^ k" by (rule less.IH) (simp add: 3)
    moreover have "fib (Suc k) < 2 ^ Suc k" by (rule less.IH) (simp add: 3)
    ultimately show ?thesis using 3 by simp
  qed
qed

lemma even_ev: "even n \<Longrightarrow> ev n"
proof (induction n rule: less_induct)
  case (less n)
  show ?case
  proof (cases n)
    case 0
    then show ?thesis by (simp add: ev_0)
  next
    case (Suc m)
    with less.prems obtain k where "n = Suc (Suc k)" by (cases m) auto
    with less.prems have "even k" and "k < n" by simp_all
    then have "ev k" using less.IH by blast
    with \<open>n = Suc (Suc k)\<close> show ?thesis by (simp add: ev_SS)
  qed
qed

lemma "ev n \<longleftrightarrow> even n"
  using ev_even even_ev by blast

lemma "sorted xs \<Longrightarrow> sorted ys \<Longrightarrow> sorted (merge xs ys)"
  by (induction xs ys rule: merge.induct) (auto simp: set_merge)

end
