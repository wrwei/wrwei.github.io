theory Module_07
  imports Main
begin

lemma "A \<Longrightarrow> A \<or> B"

  by blast

lemma "A \<longrightarrow> A \<or> B"

  by blast

thm not_def

thm conjI

thm conjI[of "door_closed" "lift_stopped"]

thm conjI conjunct1 conjunct2 conjE disjI1 disjI2 disjE

thm impI mp impE notI notE FalseE

thm allI spec allE exI exE

thm ccontr classical refl subst ssubst iffI iffD1 iffD2

lemma swap_and: "A \<and> B \<longrightarrow> B \<and> A"

  apply (rule impI)

  apply (rule conjI)

  apply (rule conjunct2)

  apply assumption

  apply (rule conjunct1)

  apply assumption

  done

thm swap_and

lemma "A \<and> B \<longrightarrow> B \<and> A"
  apply (rule impI)

  apply (erule conjE)

  apply (rule conjI)

  apply assumption
  apply assumption
  done

lemma swap_or: "A \<or> B \<longrightarrow> B \<or> A"
  apply (rule impI)

  apply (erule disjE)

  apply (rule disjI2)

  apply assumption

  apply (rule disjI1)

  apply assumption
  done

lemma imp_chain: "(A \<longrightarrow> B) \<longrightarrow> (B \<longrightarrow> C) \<longrightarrow> (A \<longrightarrow> C)"
  apply (rule impI)

  apply (rule impI)

  apply (rule impI)

  apply (drule mp)

  apply assumption

  apply (drule mp)

  apply assumption
  apply assumption
  done

lemma "A \<and> B \<longrightarrow> B \<and> A"
  apply (rule impI)
  apply (frule conjunct1)

  apply (drule conjunct2)

  apply (rule conjI)
  apply assumption
  apply assumption
  done

lemma "A \<and> B \<longrightarrow> B \<and> A"
  apply (intro impI conjI)

  apply (elim conjE)

  apply assumption
  apply (elim conjE)
  apply assumption
  done

lemma "\<not> (A \<or> B) \<longrightarrow> \<not> A \<and> \<not> B"
  apply (rule impI)
  apply (rule conjI)

  apply (rule notI)

  apply (erule notE)

  apply (rule disjI1)
  apply assumption

  apply (rule notI)
  apply (erule notE)
  apply (rule disjI2)
  apply assumption
  done

lemma "False \<longrightarrow> A"
  apply (rule impI)

  apply (erule FalseE)
  done

lemma "(\<forall>x. P x \<and> Q x) \<longrightarrow> (\<forall>x. P x) \<and> (\<forall>x. Q x)"
  apply (rule impI)
  apply (rule conjI)

  apply (rule allI)

  apply (erule allE)

  apply (erule conjE)

  apply assumption

  apply (rule allI)
  apply (drule spec)

  apply (erule conjE)
  apply assumption
  done

lemma all_inst: "\<forall>x. P x \<Longrightarrow> P x"
  apply (erule allE)
  apply assumption
  done

thm all_inst

lemma ex_all: "(\<exists>x. \<forall>y. R x y) \<longrightarrow> (\<forall>y. \<exists>x. R x y)"
  apply (rule impI)
  apply (rule allI)

  apply (erule exE)

  apply (rule exI)

  apply (erule allE)

  apply assumption
  done

lemma "(\<exists>x. \<forall>y. R x y) \<longrightarrow> (\<forall>y. \<exists>x. R x y)"
  apply (rule impI)
  apply (rule allI)
  apply (rule exI)

  apply (erule exE)

  apply (erule allE)

  oops

lemma "\<exists>n::nat. n + n = 6"
  apply (rule exI)

  oops

lemma "\<exists>n::nat. n + n = 6"
  apply (rule_tac x = 3 in exI)

  apply simp
  done

lemma "\<lbrakk>\<forall>x. safe x \<longrightarrow> safe (step x); safe s\<rbrakk> \<Longrightarrow> safe (step (step s))"
  apply (frule spec)

  apply (erule impE)
  apply assumption

  apply (erule allE)
  apply (erule impE)
  apply assumption

  oops

lemma safe_twice: "\<lbrakk>\<forall>x. safe x \<longrightarrow> safe (step x); safe s\<rbrakk> \<Longrightarrow> safe (step (step s))"
  apply (frule spec)
  apply (erule impE)
  apply assumption
  apply (erule_tac x = "step s" in allE)

  apply (erule impE)
  apply assumption
  apply assumption
  done

lemma "A \<or> \<not> A"
  apply (rule disjI1)

  oops

lemma "A \<or> \<not> A"
  apply (rule ccontr)

  apply (rule notE)

  apply assumption

  apply (rule disjI2)
  apply (rule notI)

  apply (erule notE)

  apply (rule disjI1)
  apply assumption
  done

lemma "A \<or> \<not> A"
  apply (rule classical)

  apply (rule disjI2)
  apply (rule notI)
  apply (erule notE)
  apply (rule disjI1)
  apply assumption
  done

thm excluded_middle

lemma de_morgan_and: "\<not> (A \<and> B) \<longrightarrow> \<not> A \<or> \<not> B"
  apply (rule impI)
  apply (rule ccontr)

  apply (erule notE)

  apply (rule conjI)
  apply (rule ccontr)

  apply (erule notE)
  apply (rule disjI1)
  apply assumption

  apply (rule ccontr)
  apply (erule notE)
  apply (rule disjI2)
  apply assumption
  done

lemma "s = t \<Longrightarrow> t = s"
  apply (erule subst)

  apply (rule refl)
  done

lemma "A \<and> B \<longleftrightarrow> B \<and> A"

  apply (rule iffI)

  apply (erule conjE)
  apply (rule conjI)
  apply assumption
  apply assumption
  apply (erule conjE)
  apply (rule conjI)
  apply assumption
  apply assumption
  done

lemma "A \<or> B \<longrightarrow> B \<or> A"
  apply (rule impI)
  apply (rule disjE)

  oops

lemma "\<not> (A \<and> B) \<longrightarrow> \<not> A \<or> \<not> B"
  by blast

lemma "(\<exists>x. \<forall>y. R x y) \<longrightarrow> (\<forall>y. \<exists>x. R x y)"
  by blast

lemma "\<lbrakk>\<forall>x. safe x \<longrightarrow> safe (step x); safe s\<rbrakk> \<Longrightarrow> safe (step (step s))"
  by blast

lemma "(\<forall>y. \<exists>x. R x y) \<longrightarrow> (\<exists>x. \<forall>y. R x y)"
  apply auto

  oops

end
