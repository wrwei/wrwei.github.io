theory Module_13_Solutions
  imports Module_13
begin

value "run [Press, Press, ToAmber, ToGreen, ToRed] start"

lemma reach_run: "reach s \<Longrightarrow> reach (run es s)"
  by (induction es arbitrary: s) (auto intro: reach.step)

corollary "reach (run es start)"
  by (simp add: reach.init reach_run)

fun guard_safe :: "event \<Rightarrow> crossing \<Rightarrow> bool" where
  "guard_safe ToGreen s = (cars s = Red \<and> peds s = DontWalk \<and> \<not> req s)"
| "guard_safe e s = guard e s"

inductive reach_fixed :: "crossing \<Rightarrow> bool" where
  init: "reach_fixed start"
| step: "reach_fixed s \<Longrightarrow> guard_safe e s \<Longrightarrow> reach_fixed (effect_early e s)"

lemma "reach_fixed s \<Longrightarrow> safe s"
proof (induction rule: reach_fixed.induct)
  case init
  show ?case by (simp add: safe_def start_def)
next
  case (step s e)
  then show ?case by (cases e) (auto simp: safe_def)
qed

lemma "reach s \<Longrightarrow> cars s = Amber \<longrightarrow> req s"
proof (induction rule: reach.induct)
  case init
  show ?case by (simp add: start_def)
next
  case (step s e)
  moreover from \<open>reach s\<close> have "invar s" by (rule reach_invar)
  ultimately show ?case by (cases e) (auto simp: invar_def)
qed

lemma "greach g \<Longrightarrow> passes g \<le> coins g"
  apply (induction rule: greach.induct)
  apply auto

  oops

lemma "greach g \<Longrightarrow> passes g \<le> coins g \<and> (\<not> locked g \<longrightarrow> passes g < coins g)"
  by (induction rule: greach.induct) auto

lemma lazy_reach: "lazy s \<Longrightarrow> reach s"
proof (induction rule: lazy.induct)
  case init
  show ?case by (rule reach.init)
next
  case (press s)
  from press.IH have "reach (effect Press s)" by (rule reach.step) simp
  then show ?case by simp
qed

corollary "lazy s \<Longrightarrow> safe s"
  by (simp add: crossing_safe lazy_reach)

lemma "lazy s \<Longrightarrow> cars s = Green"
  by (induction rule: lazy.induct) (auto simp: start_def)

end
