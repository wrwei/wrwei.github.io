theory Module_02
  imports Main
begin

value "(\<not> A) \<and> (B \<longrightarrow> C)"
value "A \<longrightarrow> (B \<longrightarrow> C)"
value "(A \<longrightarrow> B) \<longrightarrow> C"

value "A \<longrightarrow> (B \<longleftrightarrow> C)"

value "True \<longrightarrow> True \<and> False \<or> False"

value "A \<or> \<not> A"

lemma "A \<or> \<not> A"

  by simp

lemma "((A \<longrightarrow> B) \<longrightarrow> A) \<longrightarrow> A"
  by blast

lemma "A \<longrightarrow> B \<longrightarrow> A \<and> B \<and> C"
  quickcheck

  nitpick

  oops

lemma "\<not> (valid \<and> \<not> expired) \<or> expired \<longleftrightarrow> (valid \<longrightarrow> expired)"
  by blast

lemma "\<not> (A \<and> B) \<longleftrightarrow> \<not> A \<and> \<not> B"
  quickcheck
  oops

lemma "A \<and> B = B \<and> A"
  quickcheck
  oops

lemma "(A \<longrightarrow> B) \<and> \<not> B \<longrightarrow> \<not> A"
  by blast

lemma "(A \<longrightarrow> B) \<and> B \<longrightarrow> A"
  nitpick
  oops

lemma "A \<and> \<not> A \<longrightarrow> B"
  by blast

lemma "((A \<longrightarrow> B) \<longrightarrow> C) \<longleftrightarrow> (A \<and> \<not> B) \<or> C"
  by blast

lemma "((A \<longrightarrow> B) \<longrightarrow> C) \<longleftrightarrow> (A \<or> C) \<and> (\<not> B \<or> C)"
  by blast

lemma "(A \<and> B) \<or> C \<longleftrightarrow> A \<and> (B \<or> C)"
  nitpick
  oops

lemma "\<not> ((A \<or> B) \<and> (\<not> A \<or> C) \<and> (\<not> B \<or> C) \<and> (\<not> C \<or> D) \<and> \<not> D)"
  by sat

lemma "\<not> ((opens \<longrightarrow> badge \<and> pin \<or> fire) \<and>
         (fire \<longrightarrow> opens) \<and>
         (lockdown \<longrightarrow> \<not> opens) \<and>
         (badge \<and> pin \<longrightarrow> opens))"
  nitpick
  oops

lemma "\<not> ((opens \<longrightarrow> badge \<and> pin \<or> fire) \<and>
         (fire \<longrightarrow> opens) \<and>
         (lockdown \<longrightarrow> \<not> opens) \<and>
         (badge \<and> pin \<longrightarrow> opens) \<and>
         fire \<and> lockdown)"
  by blast

lemma door_determined:
  "(opens \<longrightarrow> badge \<and> pin \<or> fire) \<and>
   (fire \<longrightarrow> opens) \<and>
   (lockdown \<and> \<not> fire \<longrightarrow> \<not> opens) \<and>
   (badge \<and> pin \<and> \<not> lockdown \<longrightarrow> opens)
   \<longrightarrow> (opens \<longleftrightarrow> fire \<or> badge \<and> pin \<and> \<not> lockdown)"
  by blast

lemma door_rule_ok:
  "(opens \<longleftrightarrow> fire \<or> badge \<and> pin \<and> \<not> lockdown) \<longrightarrow>
   (opens \<longrightarrow> badge \<and> pin \<or> fire) \<and>
   (fire \<longrightarrow> opens) \<and>
   (lockdown \<and> \<not> fire \<longrightarrow> \<not> opens) \<and>
   (badge \<and> pin \<and> \<not> lockdown \<longrightarrow> opens)"
  by blast

lemma "(opens \<longrightarrow> badge \<and> pin \<or> fire) \<and>
       (fire \<longrightarrow> opens) \<and>
       (lockdown \<and> \<not> fire \<longrightarrow> \<not> opens) \<and>
       (badge \<and> pin \<and> \<not> lockdown \<longrightarrow> opens)
       \<longrightarrow> (opens \<and> \<not> fire \<longrightarrow> pin)"
  by blast

lemma "(opens \<longrightarrow> badge \<and> pin \<or> fire) \<and>
       (fire \<longrightarrow> opens) \<and>
       (lockdown \<and> \<not> fire \<longrightarrow> \<not> opens) \<and>
       (badge \<and> pin \<and> \<not> lockdown \<longrightarrow> opens)
       \<longrightarrow> (lockdown \<longrightarrow> \<not> opens)"
  nitpick
  oops

end
