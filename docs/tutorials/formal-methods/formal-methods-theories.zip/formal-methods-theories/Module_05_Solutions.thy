theory Module_05_Solutions
  imports Module_05
begin

value "pow 3 2"
value "app [a] [b, c]"
value "mirror (Node Tip a (Node Tip b Tip))"

lemma lsum_app: "lsum (app xs ys) = lsum xs + lsum ys"
  apply (induction xs)

  apply auto
  done

fun odds :: "nat \<Rightarrow> nat" where
  "odds 0 = 0"
| "odds (Suc n) = odds n + (2 * n + 1)"

lemma odds_square: "odds n = n * n"
  by (induction n) auto

fun inorder :: "'a tree2 \<Rightarrow> 'a list" where
  "inorder Tip = []"
| "inorder (Node l x r) = inorder l @ [x] @ inorder r"

lemma length_inorder: "length (inorder t) = nodes t"
  by (induction t) auto

lemma inorder_mirror: "inorder (mirror t) = rev (inorder t)"
  by (induction t) auto

fun half :: "nat \<Rightarrow> nat" where
  "half 0 = 0"
| "half (Suc 0) = 0"
| "half (Suc (Suc n)) = half n + 1"

fun nbits :: "nat \<Rightarrow> nat" where
  "nbits n = (if n = 0 then 0 else nbits (n div 2) + 1)"

end
