theory Module_13
  imports Main
begin

datatype door = Open | Closing | Closed

inductive lstep :: "door \<times> bool \<Rightarrow> door \<times> bool \<Rightarrow> bool" where
  open_door:  "\<not> m \<Longrightarrow> lstep (d, m) (Open, m)"
| close_door: "d = Open \<Longrightarrow> lstep (d, m) (Closing, m)"
| shut_door:  "d = Closing \<Longrightarrow> lstep (d, m) (Closed, m)"
| start_lift: "d = Closed \<Longrightarrow> lstep (d, m) (d, True)"
| stop_lift:  "lstep (d, m) (d, False)"

inductive lreach :: "door \<times> bool \<Rightarrow> bool" where
  init: "lreach (Closed, False)"
| step: "lreach s \<Longrightarrow> lstep s t \<Longrightarrow> lreach t"

lemma "lreach (Closing, False)"
proof -
  have "lreach (Closed, False)" by (rule lreach.init)
  moreover have "lstep (Closed, False) (Open, False)" by (rule open_door) simp
  ultimately have "lreach (Open, False)" by (rule lreach.step)
  moreover have "lstep (Open, False) (Closing, False)" by (rule close_door) simp
  ultimately show "lreach (Closing, False)" by (rule lreach.step)
qed

thm lreach.induct

lemma lreach_rtrancl: "lreach s \<longleftrightarrow> ((Closed, False), s) \<in> {(s, t). lstep s t}\<^sup>*"
proof
  assume "lreach s"
  then show "((Closed, False), s) \<in> {(s, t). lstep s t}\<^sup>*"
    by induction (auto intro: rtrancl_into_rtrancl)
next
  assume "((Closed, False), s) \<in> {(s, t). lstep s t}\<^sup>*"
  then show "lreach s"
    by induction (auto intro: lreach.intros)
qed

fun lift_ok :: "door \<times> bool \<Rightarrow> bool" where
  "lift_ok (d, m) = (m \<longrightarrow> d = Closed)"

lemma lift_safe: "lreach s \<Longrightarrow> lift_ok s"
  apply (induction rule: lreach.induct)

  apply (auto elim: lstep.cases)
  done

corollary "\<not> lreach (Open, True)"
  using lift_safe by force

datatype light = Green | Amber | Red
datatype signal = Walk | DontWalk

record crossing =
  cars :: light
  peds :: signal
  req  :: bool

definition start :: crossing where
  "start = \<lparr>cars = Green, peds = DontWalk, req = False\<rparr>"

value "start\<lparr>cars := Amber\<rparr>"

datatype event = Press | ToAmber | ToRed | StartWalk | EndWalk | ToGreen

fun guard :: "event \<Rightarrow> crossing \<Rightarrow> bool" where
  "guard Press s = True"
| "guard ToAmber s = (cars s = Green \<and> req s)"
| "guard ToRed s = (cars s = Amber)"
| "guard StartWalk s = (cars s = Red \<and> peds s = DontWalk \<and> req s)"
| "guard EndWalk s = (peds s = Walk)"
| "guard ToGreen s = (cars s = Red \<and> \<not> req s)"

fun effect :: "event \<Rightarrow> crossing \<Rightarrow> crossing" where
  "effect Press s = s\<lparr>req := True\<rparr>"
| "effect ToAmber s = s\<lparr>cars := Amber\<rparr>"
| "effect ToRed s = s\<lparr>cars := Red\<rparr>"
| "effect StartWalk s = s\<lparr>peds := Walk\<rparr>"
| "effect EndWalk s = s\<lparr>peds := DontWalk, req := False\<rparr>"
| "effect ToGreen s = s\<lparr>cars := Green\<rparr>"

fun run :: "event list \<Rightarrow> crossing \<Rightarrow> crossing" where
  "run [] s = s"
| "run (e # es) s = run es (if guard e s then effect e s else s)"

value "run [Press, ToAmber, ToRed, StartWalk] start"

value "run [ToAmber, ToRed, StartWalk] start"

inductive reach :: "crossing \<Rightarrow> bool" where
  init: "reach start"
| step: "reach s \<Longrightarrow> guard e s \<Longrightarrow> reach (effect e s)"

thm reach.induct

definition safe :: "crossing \<Rightarrow> bool" where
  "safe s \<longleftrightarrow> (peds s = Walk \<longrightarrow> cars s = Red)"

lemma "safe s \<Longrightarrow> guard e s \<Longrightarrow> safe (effect e s)"
  quickcheck
  oops

lemma "reach s \<Longrightarrow> safe s"
  nitpick
  oops

definition invar :: "crossing \<Rightarrow> bool" where
  "invar s \<longleftrightarrow> (peds s = Walk \<longrightarrow> cars s = Red \<and> req s)"

lemma reach_invar: "reach s \<Longrightarrow> invar s"
proof (induction rule: reach.induct)
  case init
  show ?case by (simp add: invar_def start_def)
next
  case (step s e)
  then show ?case by (cases e) (auto simp: invar_def)
qed

theorem crossing_safe: "reach s \<Longrightarrow> safe s"
  using reach_invar by (simp add: invar_def safe_def)

fun effect_early :: "event \<Rightarrow> crossing \<Rightarrow> crossing" where
  "effect_early StartWalk s = s\<lparr>peds := Walk, req := False\<rparr>"
| "effect_early EndWalk s = s\<lparr>peds := DontWalk\<rparr>"
| "effect_early e s = effect e s"

inductive reach_early :: "crossing \<Rightarrow> bool" where
  "reach_early start"
| "reach_early s \<Longrightarrow> guard e s \<Longrightarrow> reach_early (effect_early e s)"

lemma "reach_early s \<Longrightarrow> safe s"
  nitpick [card = 6]
  oops

fun run_early :: "event list \<Rightarrow> crossing \<Rightarrow> crossing" where
  "run_early [] s = s"
| "run_early (e # es) s =
     run_early es (if guard e s then effect_early e s else s)"

lemma "safe (run_early es start)"
  nitpick [card = 6]
  oops

value "map (\<lambda>n. run_early (take n [Press, ToAmber, ToRed, StartWalk, ToGreen]) start)
         [0..<6]"

lemma "safe (run_early [e1, e2, e3, e4, e5] start)"
  quickcheck
  oops

record timed =
  lights :: crossing
  timer :: nat

fun delay :: "event \<Rightarrow> nat" where
  "delay ToAmber = 3"
| "delay ToRed = 2"
| "delay StartWalk = 6"
| "delay EndWalk = 2"
| "delay ToGreen = 10"
| "delay Press = 0"

inductive tstep :: "timed \<Rightarrow> timed \<Rightarrow> bool" where
  tick:   "timer c > 0 \<Longrightarrow> tstep c (c\<lparr>timer := timer c - 1\<rparr>)"
| press:  "tstep c (c\<lparr>lights := effect Press (lights c)\<rparr>)"
| switch: "e \<noteq> Press \<Longrightarrow> timer c = 0 \<Longrightarrow> guard e (lights c) \<Longrightarrow>
             tstep c \<lparr>lights = effect e (lights c), timer = delay e\<rparr>"

inductive treach :: "timed \<Rightarrow> bool" where
  init: "treach \<lparr>lights = start, timer = 0\<rparr>"
| step: "treach c \<Longrightarrow> tstep c c' \<Longrightarrow> treach c'"

lemma sim:
  assumes "tstep c c'"
  shows "lights c' = lights c \<or>
         (\<exists>e. guard e (lights c) \<and> lights c' = effect e (lights c))"
  using assms
proof cases
  case tick
  then show ?thesis by simp
next
  case press
  then have "guard Press (lights c) \<and> lights c' = effect Press (lights c)" by simp
  then show ?thesis by blast
next
  case (switch e)
  then show ?thesis by auto
qed

lemma treach_reach: "treach c \<Longrightarrow> reach (lights c)"
proof (induction rule: treach.induct)
  case init
  show ?case by (simp add: reach.init)
next
  case (step c c')
  from \<open>tstep c c'\<close> have "lights c' = lights c \<or>
      (\<exists>e. guard e (lights c) \<and> lights c' = effect e (lights c))"
    by (rule sim)
  with step.IH show ?case by (auto intro: reach.step)
qed

theorem timed_safe: "treach c \<Longrightarrow> safe (lights c)"
  using treach_reach crossing_safe by blast

record gate =
  locked :: bool
  coins :: nat
  passes :: nat

inductive greach :: "gate \<Rightarrow> bool" where
  "greach \<lparr>locked = True, coins = 0, passes = 0\<rparr>"
| "greach g \<Longrightarrow> greach (g\<lparr>locked := False, coins := coins g + 1\<rparr>)"
| "greach g \<Longrightarrow> \<not> locked g \<Longrightarrow> greach (g\<lparr>locked := True, passes := passes g + 1\<rparr>)"

inductive lazy :: "crossing \<Rightarrow> bool" where
  init:  "lazy start"
| press: "lazy s \<Longrightarrow> lazy (s\<lparr>req := True\<rparr>)"

end
