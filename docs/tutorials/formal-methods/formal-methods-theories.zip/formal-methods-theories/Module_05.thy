theory Module_05
  imports Main
begin

value "Suc (Suc (Suc 0))"

fun sum_upto :: "nat \<Rightarrow> nat" where
  "sum_upto 0 = 0"
| "sum_upto (Suc n) = sum_upto n + Suc n"

fun fac :: "nat \<Rightarrow> nat" where
  "fac 0 = 1"
| "fac (Suc n) = fac n * Suc n"

fun pow :: "nat \<Rightarrow> nat \<Rightarrow> nat" where
  "pow x 0 = 1"
| "pow x (Suc n) = pow x n * x"

fun fib :: "nat \<Rightarrow> nat" where
  "fib 0 = 0"
| "fib (Suc 0) = 1"
| "fib (Suc (Suc n)) = fib n + fib (Suc n)"

value "[sum_upto 3, fac 5, pow 2 10, fib 10]"

value "1 # 2 # [3 :: nat]"

fun len :: "'a list \<Rightarrow> nat" where
  "len [] = 0"
| "len (x # xs) = len xs + 1"

fun app :: "'a list \<Rightarrow> 'a list \<Rightarrow> 'a list" where
  "app [] ys = ys"
| "app (x # xs) ys = x # app xs ys"

fun reverse :: "'a list \<Rightarrow> 'a list" where
  "reverse [] = []"
| "reverse (x # xs) = app (reverse xs) [x]"

fun lsum :: "nat list \<Rightarrow> nat" where
  "lsum [] = 0"
| "lsum (x # xs) = x + lsum xs"

value "reverse [a, b, c]"

datatype 'a tree2 = Tip | Node "'a tree2" 'a "'a tree2"

fun mirror :: "'a tree2 \<Rightarrow> 'a tree2" where
  "mirror Tip = Tip"
| "mirror (Node l x r) = Node (mirror r) x (mirror l)"

fun nodes :: "'a tree2 \<Rightarrow> nat" where
  "nodes Tip = 0"
| "nodes (Node l x r) = nodes l + nodes r + 1"

fun tips :: "'a tree2 \<Rightarrow> nat" where
  "tips Tip = 1"
| "tips (Node l x r) = tips l + tips r"

value "mirror (Node (Node Tip 1 Tip) 2 (Node (Node Tip 3 Tip) 4 Tip) :: nat tree2)"

lemma sum_formula: "2 * sum_upto n = n * (n + 1)"
  apply (induction n)

  apply simp

  apply simp

  done

lemma "2 * sum_upto n = n * (n + 1)"
  by (induction n) simp_all

lemma pow_gt: "n < pow 2 n"
  by (induction n) auto

lemma len_app: "len (app xs ys) = len xs + len ys"
  apply (induction xs)

  apply auto
  done

lemma mirror_mirror: "mirror (mirror t) = t"
  apply (induction t)

  apply auto
  done

lemma tips_nodes: "tips t = nodes t + 1"
  by (induction t) auto

lemma app_nil [simp]: "app xs [] = xs"
  by (induction xs) auto

lemma app_assoc [simp]: "app (app xs ys) zs = app xs (app ys zs)"
  by (induction xs) auto

lemma reverse_app [simp]: "reverse (app xs ys) = app (reverse ys) (reverse xs)"
  by (induction xs) auto

lemma reverse_reverse: "reverse (reverse xs) = xs"
  by (induction xs) auto

lemma fib_bound: "fib n < 2 ^ n \<and> fib (Suc n) < 2 ^ Suc n"
  apply (induction n)

  apply auto
  done

fun ack :: "nat \<Rightarrow> nat \<Rightarrow> nat" where
  "ack 0 n = Suc n"
| "ack (Suc m) 0 = ack m 1"
| "ack (Suc m) (Suc n) = ack m (ack (Suc m) n)"

value "ack 2 3"

fun insert_coin :: "nat \<Rightarrow> nat \<Rightarrow> nat" where
  "insert_coin c m = (if c = 5 \<or> c = 10 then m + c else m)"

fun credit :: "nat list \<Rightarrow> nat" where
  "credit [] = 0"
| "credit (c # cs) = insert_coin c (credit cs)"

value "credit [10, 3, 5]"

lemma credit_mod: "credit cs mod 5 = 0"
  apply (induction cs)

  apply auto
  done

end
