theory Module_12_Solutions
  imports Module_12
begin

lemma "sorted (isort (rev xs)) \<and> mset (isort (rev xs)) = mset xs"
  by (simp add: sorted_isort mset_isort)

lemma "sorted (isort (isort xs)) \<and> mset (isort (isort xs)) = mset xs"
  by (simp add: sorted_isort mset_isort)

lemma "sorted (rev (isort xs))"
  quickcheck
  oops

lemma "mset (remdups (isort xs)) = mset xs"
  quickcheck
  oops

value "list_of (Queue [1] [3, 2 :: nat])"
value "qinv (Queue [] [2, 1 :: nat])"
value "deq (Queue [1] [3, 2 :: nat])"
value "enq 4 (qempty :: nat queue)"

value "bst (Nd (Nd Lf 2 Lf) 3 (Nd Lf 1 Lf) :: int btree)"
value "bst (Nd Lf 1 (Nd (Nd Lf 2 Lf) 3 Lf) :: int btree)"
value "bst (Nd (Nd Lf 1 (Nd Lf 4 Lf)) 3 (Nd Lf 5 Lf) :: int btree)"
value "bst_local (Nd (Nd Lf 1 (Nd Lf 4 Lf)) 3 (Nd Lf 5 Lf) :: int btree)"
value "tinsert 3 t0"

lemma length_ins: "length (ins x xs) = Suc (length xs)"
  by (induction xs) auto

lemma "length (isort xs) = length xs"
  by (induction xs) (auto simp: length_ins)

find_theorems "size (mset _)"

lemma "length (isort xs) = length xs"
proof -
  have "size (mset (isort xs)) = size (mset xs)" by (simp add: mset_isort)
  then show ?thesis by simp
qed

lemma "sorted (isort_bad xs)"
  quickcheck
  oops

lemma "mset (isort_bad xs) = mset xs"
  quickcheck
  oops

lemma "isempty q = (list_of q = [])"
  quickcheck
  oops

lemma isempty_correct: "qinv q \<Longrightarrow> isempty q = (list_of q = [])"
  by (cases q) auto

lemma isort_sort: "isort xs = sort xs"
proof -
  have "sort xs = isort xs"
    using mset_isort sorted_isort by (rule properties_for_sort)
  then show ?thesis by simp
qed

lemma set_inorder: "set (inorder t) = set_of t"
  by (induction t) auto

lemma sorted_inorder: "bst t \<Longrightarrow> sorted (inorder t)"
  by (induction t)
     (auto simp: sorted_append set_inorder intro: less_imp_le less_trans)

lemma bst_build: "bst (build xs)"
  by (induction xs) (auto simp: bst_tinsert)

lemma set_of_build: "set_of (build xs) = set xs"
  by (induction xs) (auto simp: set_of_tinsert)

lemma "sorted (tsort xs) \<and> set (tsort xs) = set xs"
  by (simp add: tsort_def sorted_inorder bst_build set_inorder set_of_build)

lemma "mset (tsort xs) = mset xs"
  quickcheck
  oops

end
