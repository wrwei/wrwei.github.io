theory Module_06
  imports Main
begin

lemma "A \<and> B \<longrightarrow> B \<and> A"
  by blast

lemma "(A \<longrightarrow> B) \<longrightarrow> (B \<longrightarrow> C) \<longrightarrow> (A \<longrightarrow> C)"
  by blast

lemma "A \<or> B \<longrightarrow> B \<or> A"
  by blast

lemma "\<not>(A \<or> B) \<longrightarrow> \<not>A \<and> \<not>B"
  by blast

lemma "\<not>\<not>A \<longrightarrow> A"
  by blast

lemma "A \<or> \<not>A"
  by blast

lemma "\<not>(A \<and> B) \<longrightarrow> \<not>A \<or> \<not>B"
  by blast

lemma "(\<forall>x. P x \<and> Q x) \<longrightarrow> (\<forall>x. P x) \<and> (\<forall>x. Q x)"
  by blast

lemma "(\<exists>k. \<forall>d. opens k d) \<longrightarrow> (\<forall>d. \<exists>k. opens k d)"
  by blast

lemma "(\<forall>d. \<exists>k. opens k d) \<longrightarrow> (\<exists>k. \<forall>d. opens k d)"
  nitpick [card = 2]
  oops

lemma "s = t \<longrightarrow> t = s"
  by blast

end
