theory Module_06_Solutions
  imports Module_06
begin

lemma "(\<exists>x. P x) \<and> (\<exists>x. Q x) \<longrightarrow> (\<exists>x. P x \<and> Q x)"
  nitpick [card = 2]
  oops

lemma "(\<forall>x. P x) \<longrightarrow> (\<exists>x. P x)"
  by blast

end
