theory Module_14
  imports Main
begin

type_synonym vname = string
type_synonym state = "vname \<Rightarrow> int"

datatype expr = Num int | Var vname | Add expr expr

definition sample :: expr where
  "sample = Add (Var ''x'') (Add (Num 2) (Var ''y''))"

fun eval :: "expr \<Rightarrow> state \<Rightarrow> int" where
  "eval (Num n) s = n"
| "eval (Var x) s = s x"
| "eval (Add a b) s = eval a s + eval b s"

definition s0 :: state where
  "s0 = (\<lambda>_. 0)(''x'' := 5, ''y'' := 7)"

value "(s0 ''x'', s0 ''y'', s0 ''z'')"

value "eval sample s0"

datatype instr = PUSH int | LOAD vname | ADD

type_synonym stack = "int list"

fun exec1 :: "instr \<Rightarrow> state \<Rightarrow> stack \<Rightarrow> stack" where
  "exec1 (PUSH n) s stk = n # stk"
| "exec1 (LOAD x) s stk = s x # stk"
| "exec1 ADD s (j # i # stk) = (i + j) # stk"
| "exec1 ADD s stk = stk"

thm exec1.simps

fun exec :: "instr list \<Rightarrow> state \<Rightarrow> stack \<Rightarrow> stack" where
  "exec [] s stk = stk"
| "exec (i # c) s stk = exec c s (exec1 i s stk)"

value "exec1 ADD s0 [7, 5]"

value "exec [LOAD ''x'', PUSH 2, LOAD ''y'', ADD, ADD] s0 []"

value "exec [LOAD ''x'', PUSH 2] s0 [100]"

fun compile :: "expr \<Rightarrow> instr list" where
  "compile (Num n) = [PUSH n]"
| "compile (Var x) = [LOAD x]"
| "compile (Add a b) = compile a @ compile b @ [ADD]"

value "compile sample"

value "(exec (compile sample) s0 [100], eval sample s0 # [100])"

term comp

lemma "exec (compile e) s stk = eval e s # stk"
  quickcheck [size = 3]
  oops

lemma "exec (compile e) s stk = [eval e s]"
  quickcheck
  oops

fun compile_bad :: "expr \<Rightarrow> instr list" where
  "compile_bad (Num n) = [PUSH n]"
| "compile_bad (Var x) = [LOAD x]"
| "compile_bad (Add a b) = compile_bad a @ [ADD] @ compile_bad b"

value "(compile_bad sample, exec (compile_bad sample) s0 [])"

lemma "exec (compile_bad e) s stk = eval e s # stk"
  quickcheck
  oops

lemma "exec (compile e) s [] = [eval e s]"
  apply (induction e)
  apply auto

  oops

value "(exec ([LOAD ''x'', PUSH 2] @ [ADD]) s0 [1],
        exec [ADD] s0 (exec [LOAD ''x'', PUSH 2] s0 [1]))"

lemma "exec (c1 @ c2) s stk = exec c2 s (exec c1 s stk)"
  quickcheck [size = 3]
  oops

lemma exec_append [simp]: "exec (c1 @ c2) s stk = exec c2 s (exec c1 s stk)"
  apply (induction c1 arbitrary: stk)

  apply auto
  done

lemma "exec (compile e) s [] = [eval e s]"
  apply (induction e)
  apply auto

  oops

lemma "exec (compile e) s stk = eval e s # stk"
  by (induction e arbitrary: stk) auto

theorem compile_correct: "exec (compile e) s stk = eval e s # stk"
proof (induction e arbitrary: stk)

  case (Num n)
  show ?case by simp
next
  case (Var x)
  show ?case by simp
next
  case (Add a b)

  have run_a: "exec (compile a) s stk = eval a s # stk"
    by (rule Add.IH(1))
  have run_b: "exec (compile b) s (eval a s # stk)
               = eval b s # eval a s # stk"

    by (rule Add.IH(2))

  have "exec (compile (Add a b)) s stk
        = exec [ADD] s (exec (compile b) s (exec (compile a) s stk))"
    by simp
  also have "\<dots> = exec [ADD] s (exec (compile b) s (eval a s # stk))"
    by (simp only: run_a)
  also have "\<dots> = exec [ADD] s (eval b s # eval a s # stk)"
    by (simp only: run_b)
  also have "\<dots> = eval (Add a b) s # stk"
    by simp
  finally show ?case .
qed

corollary compile_correct_empty: "exec (compile e) s [] = [eval e s]"
  by (simp add: compile_correct)

fun fold_add :: "expr \<Rightarrow> expr \<Rightarrow> expr" where
  "fold_add (Num m) (Num n) = Num (m + n)"
| "fold_add a b = (if b = Num 0 then a else Add a b)"

fun cfold :: "expr \<Rightarrow> expr" where
  "cfold (Num n) = Num n"
| "cfold (Var x) = Var x"
| "cfold (Add a b) = fold_add (cfold a) (cfold b)"

definition sample2 :: expr where
  "sample2 = Add (Add (Num 2) (Num 3)) (Add (Var ''x'') (Num 0))"

value "cfold sample2"

value "(compile sample2, compile (cfold sample2))"

value "cfold (Add (Num 2) (Add (Num 3) (Var ''x'')))"

lemma eval_fold_add [simp]: "eval (fold_add a b) s = eval a s + eval b s"
  apply (induction a b rule: fold_add.induct)

  apply auto
  done

theorem cfold_correct: "eval (cfold e) s = eval e s"
  by (induction e) auto

theorem compile_cfold_correct:
  "exec (compile (cfold e)) s stk = eval e s # stk"
  by (simp add: compile_correct cfold_correct)

export_code compile cfold in Haskell module_name StackCompiler

datatype expr2 = Num2 int | Var2 vname | Add2 expr2 expr2
  | Sub expr2 expr2 | Cond expr2 expr2 expr2

fun eval2 :: "expr2 \<Rightarrow> state \<Rightarrow> int" where
  "eval2 (Num2 n) s = n"
| "eval2 (Var2 x) s = s x"
| "eval2 (Add2 a b) s = eval2 a s + eval2 b s"
| "eval2 (Sub a b) s = eval2 a s - eval2 b s"
| "eval2 (Cond t a b) s = (if eval2 t s \<noteq> 0 then eval2 a s else eval2 b s)"

datatype instr2 = PUSH2 int | LOAD2 vname | ADD2 | SUB | JMP nat | JMPZ nat

fun exec2 :: "instr2 list \<Rightarrow> state \<Rightarrow> stack \<Rightarrow> stack" where
  "exec2 [] s stk = stk"
| "exec2 (PUSH2 n # c) s stk = exec2 c s (n # stk)"
| "exec2 (LOAD2 x # c) s stk = exec2 c s (s x # stk)"
| "exec2 (ADD2 # c) s (j # i # stk) = exec2 c s ((i + j) # stk)"
| "exec2 (SUB # c) s (j # i # stk) = exec2 c s ((i - j) # stk)"
| "exec2 (JMP n # c) s stk = exec2 (drop n c) s stk"
| "exec2 (JMPZ n # c) s (v # stk) =
     (if v = 0 then exec2 (drop n c) s stk else exec2 c s stk)"
| "exec2 (_ # c) s stk = exec2 c s stk"

fun compile2 :: "expr2 \<Rightarrow> instr2 list" where
  "compile2 (Num2 n) = [PUSH2 n]"
| "compile2 (Var2 x) = [LOAD2 x]"
| "compile2 (Add2 a b) = compile2 a @ compile2 b @ [ADD2]"
| "compile2 (Sub a b) = compile2 a @ compile2 b @ [SUB]"
| "compile2 (Cond t a b) =
     compile2 t @ [JMPZ (length (compile2 a) + 1)] @ compile2 a @
     [JMP (length (compile2 b))] @ compile2 b"

lemma "exec2 (compile2 b @ compile2 a @ [SUB]) s stk
       = (eval2 a s - eval2 b s) # stk"
  quickcheck
  oops

value "compile2 (Cond (Var2 ''x'') (Num2 1) (Num2 2))"

value "(exec2 (compile2 (Cond (Var2 ''x'') (Num2 1) (Num2 2))) s0 [],
        exec2 (compile2 (Cond (Var2 ''z'') (Num2 1) (Num2 2))) s0 [])"

lemma "exec2 (c1 @ c2) s stk = exec2 c2 s (exec2 c1 s stk)"
  quickcheck
  oops

theorem compile2_correct:
  "exec2 (compile2 e @ c) s stk = exec2 c s (eval2 e s # stk)"
  by (induction e arbitrary: c stk) auto

corollary "exec2 (compile2 e) s stk = eval2 e s # stk"
  using compile2_correct [of e "[]"] by simp

fun fold_add_bad :: "expr \<Rightarrow> expr \<Rightarrow> expr" where
  "fold_add_bad (Num m) (Num n) = Num (m + n)"
| "fold_add_bad a (Num n) = a"
| "fold_add_bad a b = Add a b"

datatype rinstr = LDI nat int | LDV nat vname | ADDR nat nat

type_synonym regs = "nat \<Rightarrow> int"

end
