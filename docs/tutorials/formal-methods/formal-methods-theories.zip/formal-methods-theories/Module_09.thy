theory Module_09
  imports Main
begin

datatype perm = Read | Write | Admin

type_synonym 'u acl = "('u \<times> perm) list"

fun allows :: "'u acl \<Rightarrow> 'u \<Rightarrow> perm \<Rightarrow> bool" where
  "allows [] u p = False"
| "allows (e # es) u p = (e = (u, p) \<or> allows es u p)"

definition grant :: "'u \<Rightarrow> perm \<Rightarrow> 'u acl \<Rightarrow> 'u acl" where
  "grant u p es = (u, p) # es"

fun revoke :: "'u \<Rightarrow> 'u acl \<Rightarrow> 'u acl" where
  "revoke u [] = []"
| "revoke u (e # es) = (if fst e = u then revoke u es else e # revoke u es)"

value "allows [(''ann'', Read), (''bob'', Write)] ''bob'' Write"

value "revoke ''ann'' (grant ''ann'' Admin [(''bob'', Write), (''ann'', Read)])"

lemma "allows (grant u Read es) u Read"
  apply (simp only: grant_def)

  apply (simp only: allows.simps)

  apply (simp only: simp_thms)
  done

lemma "allows (grant u Read es) u Read"
  by (simp add: grant_def)

lemma allows_grant [simp]:
  "allows (grant u p es) v q = ((u, p) = (v, q) \<or> allows es v q)"
  by (simp add: grant_def)

lemma "allows (grant u Read (grant v Write es)) v Write"
  by simp

lemma allows_append [simp]:
  "allows (es @ fs) u p = (allows es u p \<or> allows fs u p)"
  apply (induction es)

  apply simp_all
  done

lemma revoke_other [simp]: "v \<noteq> u \<Longrightarrow> allows (revoke u es) v p = allows es v p"
  by (induction es) auto

lemma revoke_self [simp]: "allows (revoke u es) u p = False"
  by (induction es) auto

lemma "allows (revoke ''ann'' es) ''bob'' Read = allows es ''bob'' Read"
  by simp

lemma "v \<noteq> u \<Longrightarrow> allows (revoke u es) v p = allows es v p"
  by simp

lemma "\<lbrakk>\<forall>w. allows es w Write \<longrightarrow> allows es w Read; allows es u Write\<rbrakk>
       \<Longrightarrow> allows es u Read"
  by simp

thm if_split

lemma allows_revoke: "allows (revoke u es) v p = (v \<noteq> u \<and> allows es v p)"
  apply (induction es)
  apply simp_all

  apply auto
  done

fun owner :: "'u acl \<Rightarrow> 'u option" where
  "owner [] = None"
| "owner (e # es) = (if snd e = Admin then Some (fst e) else owner es)"

definition may_delete :: "'u \<Rightarrow> 'u acl \<Rightarrow> bool" where
  "may_delete u es = (case owner es of None \<Rightarrow> False | Some v \<Rightarrow> v = u)"

lemma "may_delete u es = (owner es = Some u)"
  apply (simp add: may_delete_def)

thm option.split

  apply (simp split: option.split)
  done

lemma "may_delete u es \<Longrightarrow> owner es = Some u"
  by (simp add: may_delete_def split: option.splits)

thm insert_commute

lemma "insert b (insert a A) = X"
  apply (simp only: insert_commute)
  oops

lemma "set (grant u p (grant v q es)) = set (grant v q (grant u p es))"
  by (simp add: grant_def insert_commute)

thm Un_ac

lemma "C \<union> B \<union> A = X"
  apply (simp only: Un_ac)
  oops

lemma "allows (grant u Read es) u Read"
  using [[simp_trace]] by simp

thm relcomp_unfold

lemma "\<lbrakk>\<forall>r. (r, Write) \<in> RP \<longrightarrow> (r, Read) \<in> RP; (u, Write) \<in> UR O RP\<rbrakk>
       \<Longrightarrow> (u, Read) \<in> UR O RP"
  by blast

lemma "UR \<subseteq> UR' \<Longrightarrow> UR O RP \<subseteq> UR' O RP"
  by blast

lemma "(u, p) \<in> UR O RP \<Longrightarrow> (u, p) \<in> UR O (RP - {(r, p)})"
  apply auto
  oops

lemma "\<lbrakk>\<forall>xs \<in> A. \<exists>ys. xs = ys @ ys; us \<in> A\<rbrakk> \<Longrightarrow> \<exists>n. length us = n + n"
  by fastforce

lemma "\<forall>u. (u, Write) \<in> UR O RP \<longrightarrow> (u, Read) \<in> UR O RP"
  apply clarsimp
  oops

lemma "\<lbrakk>used \<le> quota; new \<le> quota - used\<rbrakk> \<Longrightarrow> used + new \<le> (quota :: nat)"
  by linarith

lemma "(2::int) * x \<noteq> 2 * y + 1"
  by presburger

lemma "\<forall>n \<ge> 8. \<exists>a b. n = 3 * a + 5 * (b :: nat)"
  by presburger

find_theorems "rev (rev _)"

find_theorems (3) "_ * _ \<le> _ * _"

find_theorems "(_::nat) * _ \<le> _ * _" name: mono

lemma "(x::nat) \<le> y \<Longrightarrow> x * x \<le> y * y"
  by (simp add: mult_le_mono)

find_theorems simp: "set (filter _ _)"

find_consts "'a list \<Rightarrow> 'a set"

lemma "allows es u Write \<Longrightarrow> allows es u Read"
  quickcheck
  oops

lemma "allows es u Write \<Longrightarrow> allows es u Read"
  quickcheck [random]
  oops

lemma "revoke u (grant u p es) = es"
  quickcheck
  oops

lemma "allows (revoke u es) v p = (v \<noteq> u \<and> allows es v p)"
  quickcheck
  oops

lemma "(r::'r, Read) \<in> RP \<Longrightarrow> (u::'u, Read) \<notin> (UR - {(u, r)}) O RP"
  nitpick [card 'u = 1, card 'r = 2]
  oops

lemma "\<lbrakk>(r::'r, Read) \<in> RP; \<forall>r'. (u::'u, r') \<in> UR \<and> (r', Read) \<in> RP \<longrightarrow> r' = r\<rbrakk>
       \<Longrightarrow> (u, Read) \<notin> (UR - {(u, r)}) O RP"
  nitpick [card 'u = 1, card 'r = 2]

  by blast

lemma "(x::nat) \<le> y \<Longrightarrow> x * x \<le> y * y"
  sledgehammer

  by (simp add: mult_le_mono)

lemma "\<lbrakk>es @ fs = fs @ es; length es = length fs\<rbrakk> \<Longrightarrow> es = fs"
  by (metis append_eq_append_conv)

lemma owner_admin: "owner es = Some v \<Longrightarrow> allows es v Admin"
  apply (induction es)
  apply auto

  oops

lemma owner_admin: "owner es = Some v \<Longrightarrow> allows es v Admin"
  apply (induction es)
  apply (auto split: if_splits)
  done

lemma "may_delete u es \<Longrightarrow> allows es u Admin"
  by (simp add: may_delete_def owner_admin split: option.splits)

definition wf_acl :: "'u acl \<Rightarrow> bool" where
  "wf_acl es = (\<forall>u. allows es u Write \<longrightarrow> allows es u Read)"

end
