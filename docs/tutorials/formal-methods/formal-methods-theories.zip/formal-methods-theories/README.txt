Formal Methods with Isabelle: the theories of every module and the exercise solutions,
checked with Isabelle2026. Open a .thy file in Isabelle/jEdit, or check them all with
    isabelle build -D .
