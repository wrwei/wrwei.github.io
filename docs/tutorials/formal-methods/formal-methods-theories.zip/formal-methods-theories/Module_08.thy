theory Module_08
  imports Main
begin

typ "nat \<times> bool"
typ "nat \<Rightarrow> bool list"
typ "(nat \<Rightarrow> bool) list"

term "Suc 0"
term "[Suc 0, 5]"
term "(Suc 0, [True])"

term "x + 1"

term "x + (1::nat)"

value "rev [a, b, c]"

value "lenght [1, 2::nat]"

term "\<lambda>x::nat. x + 1"

value "(\<lambda>x::nat. x * x) 7"

term "(\<lambda>x::nat. x * x) 7"

term "\<lambda>x y. x + (y::nat)"

term "(+) (3::nat)"

term "map"

value "map ((+) (3::nat)) [1, 2, 3]"

datatype light = Red | RedAmber | Green | Amber

term "Green"

fun next_light :: "light \<Rightarrow> light" where
  "next_light Red = RedAmber"
| "next_light RedAmber = Green"
| "next_light Green = Amber"
| "next_light Amber = Red"

value "next_light (next_light Red)"

lemma "Red \<noteq> Green"
  by simp

lemma "next_light (next_light (next_light (next_light l))) = l"
  apply (cases l)

  apply simp_all
  done

fun duration :: "light \<Rightarrow> nat" where
  "duration Red = 30"
| "duration RedAmber = 2"
| "duration Green = 25"
| "duration Amber = 3"

datatype 'a stack = Empty | Push 'a "'a stack"

term "Push (1::nat) (Push 2 (Push 3 Empty))"

primrec height :: "'a stack \<Rightarrow> nat" where
  "height Empty = 0"
| "height (Push x s) = Suc (height s)"

primrec to_list :: "'a stack \<Rightarrow> 'a list" where
  "to_list Empty = []"
| "to_list (Push x s) = x # to_list s"

value "to_list (Push (1::nat) (Push 2 (Push 3 Empty)))"

fun top :: "'a stack \<Rightarrow> 'a option" where
  "top Empty = None"
| "top (Push x s) = Some x"

fun pop :: "'a stack \<Rightarrow> ('a \<times> 'a stack) option" where
  "pop Empty = None"
| "pop (Push x s) = Some (x, s)"

value "pop (Push Red (Push Green Empty))"

fun top_or :: "'a \<Rightarrow> 'a stack \<Rightarrow> 'a" where
  "top_or d s = (case top s of None \<Rightarrow> d | Some x \<Rightarrow> x)"

value "top_or Red (Push Green Empty)"
value "top_or Red Empty"

value "case pop (Push Green (Push Red Empty)) of None \<Rightarrow> [] | Some (x, s) \<Rightarrow> [x, x]"

definition safe :: "light \<times> light \<Rightarrow> bool" where
  "safe p = (fst p = Red \<or> snd p = Red)"

thm safe_def

lemma "safe (Red, Green)"
  by (simp add: safe_def)

lemma "\<not> safe (Green, Amber)"
  by (simp add: safe_def)

lemma safe_Red: "safe (Red, l)"
  by (simp add: safe_def)

fun push_all :: "'a list \<Rightarrow> 'a stack \<Rightarrow> 'a stack" where
  "push_all [] s = s"
| "push_all (x # xs) s = push_all xs (Push x s)"

value "to_list (push_all [1, 2, 3::nat] Empty)"

thm height.simps

fun top_value :: "'a stack \<Rightarrow> 'a" where
  "top_value (Push x s) = x"

fun is_red :: "light \<Rightarrow> bool" where
  "is_red Red = True"
| "is_red l = False"

thm is_red.simps

fun trace :: "nat \<Rightarrow> light \<Rightarrow> light list" where
  "trace 0 l = []"
| "trace (Suc n) l = l # trace n (next_light l)"

value "trace 6 Red"

value "map duration (trace 4 Red)"

value "sum_list (map duration (trace 4 Red))"

value "filter (\<lambda>l. l = Green) (trace 9 Red)"

value "foldr (\<lambda>l t. duration l + t) (trace 4 Red) 0"

value "zip [0..<4] (trace 4 Red)"

value "length (trace 6 Red)"
value "take 2 (trace 6 Red)"
value "drop 4 (trace 6 Red)"
value "trace 6 Red ! 2"

value "[(l, duration l). l \<leftarrow> trace 4 Red, duration l < 10]"

value "Suc (Suc 0)"

value "(2::nat) - 3"
value "(2::int) - 3"

value "(17::nat) div 5"
value "(17::nat) mod 5"
value "(-17::int) div 5"
value "(-17::int) mod 5"

value "(17::nat) div 0"

declare [[show_sorts]]
term "x + 1"
term "2 + 2"
declare [[show_sorts = false]]

lemma "x + 0 = (x::nat)"
  by simp

lemma "trace 2 Red = [Red, RedAmber]"
  by (simp add: numeral_eq_Suc)

definition wait :: "light \<Rightarrow> nat" where
  "wait l = sum_list (map duration (takeWhile (\<lambda>x. x \<noteq> Green) (trace 4 l)))"

value "map wait [Red, RedAmber, Green, Amber]"

function sum_from :: "nat \<Rightarrow> nat \<Rightarrow> nat" where
  "sum_from i n = (if n < i then 0 else i + sum_from (i + 1) n)"
  by pat_completeness auto
termination
  by (relation "measure (\<lambda>(i, n). n + 1 - i)") auto

value "sum_from 3 5"

export_code next_light duration trace in Haskell module_name Traffic

fun cross :: "light \<Rightarrow> light" where
  "cross Red = Green"
| "cross RedAmber = Amber"
| "cross Green = Red"
| "cross Amber = RedAmber"

end
