theory Module_10
  imports Main
begin

lemma "(\<forall>u. admin u \<longrightarrow> staff u) \<longrightarrow> (\<exists>u. admin u) \<longrightarrow> (\<exists>u. staff u)"
  apply (rule impI)
  apply (rule impI)
  apply (erule exE)
  apply (rule exI)
  apply (erule allE)
  apply (erule mp)
  apply assumption
  done

lemma "(\<forall>u. admin u \<longrightarrow> staff u) \<longrightarrow> (\<exists>u. admin u) \<longrightarrow> (\<exists>u. staff u)"
proof (intro impI)
  assume all: "\<forall>u. admin u \<longrightarrow> staff u"
  assume "\<exists>u. admin u"
  then obtain a where "admin a" by blast
  with all have "staff a" by blast
  then show "\<exists>u. staff u" by blast
qed

lemma "A \<and> B \<longrightarrow> B \<and> A"

proof (rule impI)

  assume ab: "A \<and> B"

  show "B \<and> A"

    using ab by blast
qed

lemma "A \<and> B \<longrightarrow> B \<and> A"
proof (rule impI)
  assume ab: "A \<and> B"
  have b: "B" using ab by blast
  have a: "A" using ab by blast
  show "B \<and> A" using b a by blast
qed

lemma "A \<and> B \<longrightarrow> B \<and> A"
proof (rule impI)
  assume ab: "A \<and> B"
  show "B \<and> A"
  proof (rule conjI)

    show "B" using ab by blast
  next
    show "A" using ab by blast
  qed
qed

lemma "\<forall>u. admin u \<longrightarrow> admin u \<or> staff u"
proof

  fix u
  show "admin u \<longrightarrow> admin u \<or> staff u"
  proof
    assume a: "admin u"
    show "admin u \<or> staff u" using a by blast
  qed
qed

fun clamp :: "int \<Rightarrow> int \<Rightarrow> int \<Rightarrow> int" where
  "clamp lo hi x = (if x < lo then lo else if hi < x then hi else x)"

value "clamp 0 100 150"
value "clamp 0 100 (-5)"
value "clamp 0 100 42"

lemma clamp_lower:
  assumes "lo \<le> hi"
  shows "lo \<le> clamp lo hi x"

proof -
  show ?thesis using assms by simp
qed

lemma
  assumes "A" and "\<not> A"
  shows False
proof -
  show False using assms by blast
qed

lemma "A \<and> (A \<longrightarrow> B) \<longrightarrow> B \<or> C"
proof (rule impI)
  assume "A \<and> (A \<longrightarrow> B)"
  then have "B"

    by blast
  then show "B \<or> C" by blast
qed

lemma "A \<and> B \<longrightarrow> B \<and> A"
proof (rule impI)
  assume ab: "A \<and> B"
  from ab have "A" by blast
  from ab have "B" by blast
  with \<open>A\<close> show "B \<and> A" by blast
qed

lemma "A \<and> B \<longrightarrow> B \<and> A"
proof (rule impI)
  assume ab: "A \<and> B"
  from ab have a: "A" by blast
  from ab have b: "B" by blast
  note both = b a

  from both show "B \<and> A" by (rule conjI)
qed

lemma clamp_in_range:
  assumes "lo \<le> hi"
  shows "lo \<le> clamp lo hi x \<and> clamp lo hi x \<le> hi"
proof -
  have "lo \<le> clamp lo hi x" using assms by simp
  moreover have "clamp lo hi x \<le> hi" using assms by simp
  ultimately show ?thesis by blast
qed

lemma "(a + b) * (a + b) = a * a + 2 * a * b + b * (b :: int)"
proof -
  have "(a + b) * (a + b) = a * (a + b) + b * (a + b)" by (rule distrib_right)
  also have "\<dots> = a * a + a * b + (b * a + b * b)" by (simp add: distrib_left)
  also have "\<dots> = a * a + 2 * a * b + b * b" by (simp add: algebra_simps)
  finally show ?thesis .
qed

lemma heap_child:
  fixes i n :: nat
  assumes "i < n"
  shows "2 * i + 1 < 2 * n"
proof -
  have "2 * i + 1 < 2 * i + 2" by simp
  also have "\<dots> = 2 * (i + 1)" by simp
  also have "\<dots> \<le> 2 * n" using assms by simp
  finally show ?thesis .
qed

lemma clamp_max_min:
  assumes "lo \<le> hi"
  shows "clamp lo hi x = max lo (min hi x)"
proof (cases "x < lo")

  case True

  then show ?thesis using assms by simp
next
  case False
  then show ?thesis using assms by simp
qed

fun first_or :: "'a \<Rightarrow> 'a list \<Rightarrow> 'a" where
  "first_or d [] = d"
| "first_or d (y # ys) = y"

lemma first_or_append: "first_or d (xs @ ys) = first_or (first_or d ys) xs"
proof (cases xs)

  case Nil
  then show ?thesis by simp
next
  case (Cons z zs)

  then show ?thesis by simp
qed

lemma
  assumes who: "owner u \<or> admin u"
    and owners: "\<forall>v. owner v \<longrightarrow> may_read v"
    and admins: "\<forall>v. admin v \<longrightarrow> may_read v"
  shows "may_read u"
  using who
proof
  assume "owner u"
  with owners show ?thesis by blast
next
  assume "admin u"
  with admins show ?thesis by blast
qed

lemma
  assumes "lo \<le> hi"
  shows "lo \<le> clamp lo hi x \<and> clamp lo hi x \<le> hi"
proof -
  consider (below) "x < lo" | (inside) "lo \<le> x" "x \<le> hi" | (above) "hi < x"
    by linarith
  then show ?thesis
  proof cases
    case below
    then show ?thesis using assms by simp
  next
    case inside
    then show ?thesis by simp
  next
    case above
    then show ?thesis using assms by simp
  qed
qed

fun mysum :: "nat list \<Rightarrow> nat" where
  "mysum [] = 0"
| "mysum (x # xs) = x + mysum xs"

lemma mysum_append: "mysum (xs @ ys) = mysum xs + mysum ys"
proof (induction xs)

  case Nil
  show ?case by simp
next
  case (Cons x xs)

  then show ?case by simp
qed

lemma "mysum (xs @ ys) = mysum xs + mysum ys"
proof (induction xs)
  case Nil
  show ?case by simp
next
  case (Cons x xs)
  have "mysum ((x # xs) @ ys) = x + mysum (xs @ ys)" by simp
  also have "\<dots> = x + (mysum xs + mysum ys)" using Cons.IH by simp
  also have "\<dots> = mysum (x # xs) + mysum ys" by simp
  finally show ?case .
qed

lemma mysum_bound: "(\<forall>x \<in> set xs. x \<le> m) \<Longrightarrow> mysum xs \<le> length xs * m"
proof (induction xs)
  print_cases

  case Nil
  then show ?case by simp
next
  case (Cons a xs)
  have "mysum (a # xs) = a + mysum xs" by simp
  also have "\<dots> \<le> m + mysum xs" using Cons.prems by simp
  also have "\<dots> \<le> m + length xs * m" using Cons.IH Cons.prems by simp
  also have "\<dots> = length (a # xs) * m" by simp
  finally show ?case .
qed

lemma "A \<and> B \<longrightarrow> B \<and> A"
  apply (rule impI)
  apply (erule conjE)
  apply (rule conjI)
  apply assumption
  apply assumption
  done

thm conjunct1 conjunct2

lemma "A \<and> B \<longrightarrow> B \<and> A"
proof (rule impI)
  assume ab: "A \<and> B"
  from ab have b: "B" by (rule conjunct2)
  from ab have a: "A" by (rule conjunct1)
  from b a show "B \<and> A" by (rule conjI)
qed

fun sum_upto :: "nat \<Rightarrow> nat" where
  "sum_upto 0 = 0"
| "sum_upto (Suc n) = sum_upto n + Suc n"

lemma "2 * sum_upto n = n * (n + 1)"
  apply (induction n)
  apply simp
  apply simp
  done

lemma sum_formula: "2 * sum_upto n = n * (n + 1)"
proof (induction n)
  case 0
  show ?case by simp
next
  case (Suc n)
  have "2 * sum_upto (Suc n) = 2 * (sum_upto n + Suc n)" by simp
  also have "\<dots> = 2 * sum_upto n + 2 * Suc n" by simp
  also have "\<dots> = n * (n + 1) + 2 * Suc n" using Suc.IH by simp
  also have "\<dots> = Suc n * (Suc n + 1)" by simp
  finally show ?case .
qed

lemma "(A \<longrightarrow> B) \<longrightarrow> (B \<longrightarrow> C) \<longrightarrow> A \<longrightarrow> C"
  apply (intro impI)
  apply (erule mp)
  apply (erule mp)
  apply assumption
  done

lemma "(A \<longrightarrow> B) \<longrightarrow> (B \<longrightarrow> C) \<longrightarrow> A \<longrightarrow> C"
proof (intro impI)
  assume ab: "A \<longrightarrow> B" and bc: "B \<longrightarrow> C" and a: "A"
  from ab a have b: "B" by (rule mp)
  from bc b show "C" by (rule mp)
qed

lemma
  assumes valid: "valid pw"
    and fresh: "\<not> locked u"
    and policy: "\<forall>p v. valid p \<and> \<not> locked v \<longrightarrow> login v p"
  shows "login u pw \<and> valid pw"
proof -
  from valid fresh have "valid pw \<and> \<not> locked u" by blast
  with policy have "login u pw" by blast
  then show ?thesis using valid by blast
qed

lemma "(A \<longrightarrow> B) \<and> A \<longrightarrow> B \<or> C"
proof
  assume prem: "(A \<longrightarrow> B) \<and> A"
  hence "A \<longrightarrow> B" by blast
  with prem have "B" by blast
  thus "B \<or> C" by blast
qed

datatype 'a tree2 = Tip | Node "'a tree2" 'a "'a tree2"

fun mirror :: "'a tree2 \<Rightarrow> 'a tree2" where
  "mirror Tip = Tip"
| "mirror (Node l x r) = Node (mirror r) x (mirror l)"

end
