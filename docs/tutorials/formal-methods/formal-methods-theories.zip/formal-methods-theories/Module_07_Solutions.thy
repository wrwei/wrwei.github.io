theory Module_07_Solutions
  imports Module_07
begin

lemma "\<lbrakk>A \<longrightarrow> B; A\<rbrakk> \<Longrightarrow> C"
  apply (erule impE)

  oops

lemma "A \<longrightarrow> B \<longrightarrow> A \<and> B"
  apply (rule impI)
  apply (rule impI)

  apply (rule conjI)
  apply assumption
  apply assumption
  done

lemma "\<lbrakk>A; B\<rbrakk> \<Longrightarrow> B \<and> A"
  apply (rule conjI)
  apply assumption
  apply assumption
  done

lemma "A \<and> B \<Longrightarrow> B"
  apply (erule conjE)
  apply assumption
  done

lemma "\<not> A \<Longrightarrow> A \<longrightarrow> B"
  apply (rule impI)
  apply (erule notE)
  apply assumption
  done

lemma "\<forall>x. P x \<Longrightarrow> P c"
  apply (erule allE)
  apply assumption
  done

lemma "P c \<Longrightarrow> \<exists>x. P x"
  apply (rule exI)
  apply assumption
  done

lemma "(A \<longrightarrow> B \<longrightarrow> C) \<longrightarrow> (A \<and> B \<longrightarrow> C)"
  apply (rule impI)
  apply (rule impI)
  apply (erule conjE)
  apply (drule mp)
  apply assumption
  apply (drule mp)
  apply assumption
  apply assumption
  done

lemma "(A \<and> B \<longrightarrow> C) \<longrightarrow> (A \<longrightarrow> B \<longrightarrow> C)"
  apply (rule impI)
  apply (rule impI)
  apply (rule impI)
  apply (erule impE)

  apply (rule conjI)
  apply assumption
  apply assumption
  apply assumption
  done

lemma "\<not> A \<or> \<not> B \<longrightarrow> \<not> (A \<and> B)"
  apply (rule impI)
  apply (rule notI)
  apply (erule conjE)
  apply (erule disjE)
  apply (erule notE)
  apply assumption
  apply (erule notE)
  apply assumption
  done

lemma "\<not> A \<and> \<not> B \<longrightarrow> \<not> (A \<or> B)"
  apply (rule impI)
  apply (erule conjE)
  apply (rule notI)
  apply (erule disjE)

  apply (erule notE)
  apply assumption
  apply (erule_tac P = B in notE)

  apply assumption
  done

lemma "(\<forall>u. admin u \<longrightarrow> can_write u) \<longrightarrow> (\<forall>u. \<not> can_write u \<longrightarrow> \<not> admin u)"
  apply (rule impI)
  apply (rule allI)
  apply (rule impI)
  apply (rule notI)

  apply (erule allE)
  apply (erule impE)
  apply assumption

  apply (erule notE)
  apply assumption
  done

lemma "(\<exists>x. P x \<and> Q x) \<longrightarrow> (\<exists>x. P x) \<and> (\<exists>x. Q x)"
  apply (rule impI)
  apply (erule exE)
  apply (erule conjE)
  apply (rule conjI)

  apply (rule exI)
  apply assumption
  apply (rule exI)
  apply assumption
  done

lemma "((A \<longrightarrow> B) \<longrightarrow> A) \<longrightarrow> A"
  apply (rule impI)
  apply (rule ccontr)
  apply (rule notE)
  apply assumption

  apply (erule impE)

  apply (rule impI)
  apply (erule notE)

  apply assumption
  apply assumption
  done

lemma "((A \<longrightarrow> B) \<longrightarrow> A) \<longrightarrow> A"
  apply (rule impI)
  apply (rule classical)

  apply (erule impE)
  apply (rule impI)
  apply (erule notE)
  apply assumption
  apply assumption
  done

lemma "(\<forall>y. \<exists>x. R x y) \<longrightarrow> (\<exists>x. \<forall>y. R x y)"
  apply (rule impI)
  apply (rule exI)
  apply (rule allI)
  apply (erule allE)
  apply (erule exE)

  oops

end
