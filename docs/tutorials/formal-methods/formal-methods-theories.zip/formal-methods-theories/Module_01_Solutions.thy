theory Module_01_Solutions
  imports Module_01
begin

fun triple :: "nat \<Rightarrow> nat" where
  "triple n = n + n + n"

value "triple 14"

lemma "triple n = 3 * n"
  by simp

lemma "triple n = double n + n"
  by simp

lemma "rev (xs @ ys) = rev xs @ rev ys"
  quickcheck
  oops

lemma "rev (xs @ ys) = rev ys @ rev xs"
  by simp

end
