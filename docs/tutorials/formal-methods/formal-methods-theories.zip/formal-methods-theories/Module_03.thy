theory Module_03
  imports Main
begin

lemma "\<forall>x. (P x \<longrightarrow> Q x)"

  oops

lemma "(\<forall>x. P x) \<longrightarrow> Q x"

  oops

value "\<forall>x::bool. \<exists>y. y \<noteq> x"

value "\<exists>y::bool. \<forall>x. y \<noteq> x"

lemma "(\<forall>x. P x \<longrightarrow> Q x) \<and> P c \<longrightarrow> Q c"
  by blast

lemma "P a \<longrightarrow> (\<forall>x. P x)"
  nitpick [card 'a = 2]

  oops

lemma "\<not> (\<forall>x. P x) \<longleftrightarrow> (\<exists>x. \<not> P x)"
  by blast

lemma "(\<forall>x. P x \<and> Q x) \<longleftrightarrow> (\<forall>x. P x) \<and> (\<forall>x. Q x)"
  by blast

lemma "(\<forall>x. P x \<longrightarrow> S) \<longleftrightarrow> ((\<exists>x. P x) \<longrightarrow> S)"
  by blast

lemma "(\<exists>y. \<forall>x. R x y) \<longrightarrow> (\<forall>x. \<exists>y. R x y)"
  by blast

lemma "(\<forall>x. \<exists>y. R x y) \<longrightarrow> (\<exists>y. \<forall>x. R x y)"
  nitpick [card = 2]

  oops

lemma "\<forall>x. P x \<and> Q x \<longleftrightarrow> (\<forall>x. P x) \<and> (\<forall>x. Q x)"

  nitpick [card 'a = 2]

  oops

lemma "(\<forall>x. \<exists>y. R x y) \<longrightarrow> (\<exists>z. R y z)"
  by blast

lemma "(\<forall>x. \<exists>y. R x y) \<longrightarrow> (\<exists>y. R y y)"
  nitpick [card 'a = 2]

  oops

lemma "\<not> x = y"

  oops

lemma "(A = B \<and> C) \<longleftrightarrow> (A \<longleftrightarrow> B \<and> C)"

  nitpick

  oops

lemma "(\<exists>!x. P x) \<longleftrightarrow> (\<exists>x. P x \<and> (\<forall>y. P y \<longrightarrow> y = x))"
  by blast

lemma "(\<exists>x. holds x \<and> (\<forall>y. holds y \<longrightarrow> y = x)) \<longleftrightarrow>
       (\<exists>x. holds x) \<and> (\<forall>x y. holds x \<and> holds y \<longrightarrow> x = y)"
  by blast

lemma "(\<exists>x. admin x \<and> on_call x) \<longleftrightarrow> (\<exists>x. admin x \<longrightarrow> on_call x)"
  nitpick [card 'a = 1]

  oops

typedecl user
typedecl doc

consts
  admin :: "user \<Rightarrow> bool"
  owns :: "user \<Rightarrow> doc \<Rightarrow> bool"
  can_delete :: "user \<Rightarrow> doc \<Rightarrow> bool"
  alice :: user
  report :: doc

lemma "(\<forall>u d. admin u \<longrightarrow> can_delete u d) \<and> admin alice \<longrightarrow> can_delete alice report"
  by blast

lemma "(\<forall>u d. owns u d \<longrightarrow> can_delete u d) \<longrightarrow> can_delete alice report"
  nitpick [card user = 2, card doc = 1, show_consts]

  oops

lemma "(\<forall>x. P x) \<longrightarrow> (\<exists>x. P x)"
  by blast

lemma "(\<forall>x. \<not> R x x) \<and> (\<forall>x y z. R x y \<and> R y z \<longrightarrow> R x z) \<longrightarrow> \<not> (\<forall>x. \<exists>y. R x y)"
  nitpick

  oops

end
