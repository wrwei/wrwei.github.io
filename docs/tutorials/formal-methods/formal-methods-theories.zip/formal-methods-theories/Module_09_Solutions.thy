theory Module_09_Solutions
  imports Module_09
begin

lemma "rev (rev xs @ ys) = rev ys @ xs"
  by simp

lemma "\<lbrakk>A \<subseteq> B; B \<inter> C \<subseteq> D\<rbrakk> \<Longrightarrow> A \<inter> C \<subseteq> D"
  by blast

lemma "\<lbrakk>(a::int) < b; b < c\<rbrakk> \<Longrightarrow> a + 2 \<le> c"
  by linarith

lemma "(n::nat) mod 4 = 1 \<Longrightarrow> n mod 2 = 1"
  by presburger

lemma "allows es u Admin \<Longrightarrow> allows es u Write"
  quickcheck
  oops

lemma "allows (revoke u [(u, Read)]) u Read = False"
  by (simp only: revoke.simps allows.simps fst_conv simp_thms if_True)

lemma "set (grant u p es) = insert (u, p) (set es)"
  by (simp add: grant_def)

lemma "may_delete u es \<Longrightarrow> owner es \<noteq> None"
  by (simp add: may_delete_def split: option.splits)

lemma "x \<in> set (revoke u es) \<Longrightarrow> fst x \<noteq> u"
  by (induction es) (auto split: if_splits)

lemma "revoke u (grant u p es) = revoke u es"
  by (simp add: grant_def)

lemma revoke_commute: "revoke u (revoke v es) = revoke v (revoke u es)"
  by (induction es) auto

lemma "length (revoke u es) \<le> length es"
  by (induction es) auto

definition latest :: "'u acl \<Rightarrow> ('u \<times> perm) option" where
  "latest es = (case es of [] \<Rightarrow> None | e # _ \<Rightarrow> Some e)"

lemma "latest (grant u p es) = Some (u, p)"
  by (simp add: latest_def grant_def)

lemma "(latest es = None) = (es = [])"
  by (simp add: latest_def split: list.split)

lemma "\<lbrakk>used \<le> quota; quota \<le> used + 5\<rbrakk> \<Longrightarrow> quota - used \<le> (5::nat)"
  by linarith

lemma "(x::nat) \<le> y \<Longrightarrow> 3 * x \<le> 3 * y"
  by linarith

lemma "even (n::nat) \<Longrightarrow> \<not> even (n + 1)"
  by presburger

lemma "(x::nat) \<le> y \<Longrightarrow> x * z \<le> y * z"
  by (simp add: mult_le_mono1)

lemma "(u::'u, p::perm) \<in> UR O RP \<Longrightarrow> (u, p) \<in> UR O (RP - {(r::'r, p)})"
  nitpick [card 'u = 1, card 'r = 1]
  oops

lemma "\<lbrakk>(u, r') \<in> UR; (r', p) \<in> RP; r' \<noteq> r\<rbrakk> \<Longrightarrow> (u, p) \<in> UR O (RP - {(r, p)})"
  by blast

lemma "wf_acl es \<Longrightarrow> wf_acl (revoke u es)"
  by (simp add: wf_acl_def allows_revoke)

lemma "wf_acl es \<Longrightarrow> wf_acl (grant u Write es)"
  quickcheck
  oops

lemma "wf_acl es \<Longrightarrow> wf_acl (grant u Read (grant u Write es))"
  by (simp add: wf_acl_def)

lemma "insert a (insert b (insert c A)) = insert c (insert a (insert b A))"
  by (simp only: insert_commute)

end
