theory Module_10_Solutions
  imports Module_10
begin

lemma "(A \<longrightarrow> B) \<and> A \<longrightarrow> B \<or> C"
proof
  assume prem: "(A \<longrightarrow> B) \<and> A"
  from prem have ab: "A \<longrightarrow> B" by blast
  from prem ab have b: "B" by blast
  from b show "B \<or> C" by blast
qed

lemma "A \<and> B \<longrightarrow> A"
proof
  assume "A \<and> B"
  then show "A" by blast
qed

lemma "(\<exists>x. P x \<and> Q x) \<longrightarrow> (\<exists>x. P x)"
proof
  assume "\<exists>x. P x \<and> Q x"
  then obtain a where "P a \<and> Q a" by blast
  then show "\<exists>x. P x" by blast
qed

lemma "clamp lo hi x \<le> max lo x"
proof (cases "x < lo")
  case True
  then show ?thesis by simp
next
  case False
  then show ?thesis by simp
qed

lemma "A \<or> B \<longrightarrow> B \<or> A"
proof
  assume "A \<or> B"
  then show "B \<or> A"
  proof
    assume "A"
    then show "B \<or> A" by blast
  next
    assume "B"
    then show "B \<or> A" by blast
  qed
qed

lemma "(\<exists>x. \<forall>y. R x y) \<longrightarrow> (\<forall>y. \<exists>x. R x y)"
proof
  assume "\<exists>x. \<forall>y. R x y"
  then obtain a where a: "\<forall>y. R a y" by blast
  show "\<forall>y. \<exists>x. R x y"
  proof
    fix b
    from a have "R a b" by (rule spec)
    then show "\<exists>x. R x b" by (rule exI)
  qed
qed

lemma
  fixes a b :: int
  shows "(a + b) * (a - b) = a * a - b * b"
proof -
  have "(a + b) * (a - b) = a * (a - b) + b * (a - b)" by (rule distrib_right)
  also have "\<dots> = (a * a - a * b) + (b * a - b * b)" by (simp add: right_diff_distrib)
  also have "\<dots> = a * a - b * b" by (simp add: algebra_simps)
  finally show ?thesis .
qed

lemma "mysum (rev xs) = mysum xs"
proof (induction xs)
  case Nil
  show ?case by simp
next
  case (Cons x xs)
  have "mysum (rev (x # xs)) = mysum (rev xs @ [x])" by simp
  also have "\<dots> = mysum (rev xs) + mysum [x]" by (rule mysum_append)
  also have "\<dots> = mysum xs + x" using Cons.IH by simp
  also have "\<dots> = mysum (x # xs)" by simp
  finally show ?case .
qed

lemma "mirror (mirror t) = t"
proof (induction t)
  case Tip
  show ?case by simp
next
  case (Node l x r)
  have "mirror (mirror (Node l x r)) = mirror (Node (mirror r) x (mirror l))" by simp
  also have "\<dots> = Node (mirror (mirror l)) x (mirror (mirror r))" by simp
  also have "\<dots> = Node l x r" using Node.IH by simp
  finally show ?case .
qed

lemma "length (filter P xs) \<le> length xs"
proof (induction xs)
  case Nil
  show ?case by simp
next
  case (Cons x xs)
  show ?case
  proof (cases "P x")
    case True
    then show ?thesis using Cons.IH by simp
  next
    case False
    then have "length (filter P (x # xs)) = length (filter P xs)" by simp
    also have "\<dots> \<le> length xs" by (rule Cons.IH)
    also have "\<dots> \<le> length (x # xs)" by simp
    finally show ?thesis .
  qed
qed

end
