theory Module_12
  imports Main "HOL-Library.Multiset"
begin

fun ins :: "'a::linorder \<Rightarrow> 'a list \<Rightarrow> 'a list" where
  "ins x [] = [x]"
| "ins x (y # ys) = (if x \<le> y then x # y # ys else y # ins x ys)"

fun isort :: "'a::linorder list \<Rightarrow> 'a list" where
  "isort [] = []"
| "isort (x # xs) = ins x (isort xs)"

value "isort [3, 1, 4, 1, 5, 9, 2, 6 :: int]"

thm sorted_simps

value "sorted [1, 2, 2, 5 :: nat]"
value "sorted [1, 3, 2 :: nat]"

value "mset [2, 1, 2 :: nat] = mset [1, 2, 2]"
value "mset [1, 2 :: nat] = mset [1, 2, 2]"
value "count (mset [2, 1, 2 :: nat]) 2"

thm mset.simps

value "mset [3, 1 :: nat]"

lemma "sorted (isort xs) \<and> mset (isort xs) = mset xs"
  quickcheck
  oops

lemma "sorted xs \<Longrightarrow> sorted (ins x xs)"
  apply (induction xs)
  apply auto

  oops

lemma set_ins: "set (ins x xs) = insert x (set xs)"
  by (induction xs) auto

lemma sorted_ins: "sorted xs \<Longrightarrow> sorted (ins x xs)"
proof (induction xs)
  case Nil
  show ?case by simp
next
  case (Cons y ys)
  show ?case
  proof (cases "x \<le> y")
    case True
    with Cons.prems show ?thesis by auto
  next
    case False
    with Cons show ?thesis by (auto simp: set_ins)
  qed
qed

lemma "sorted xs \<Longrightarrow> sorted (ins x xs)"
  by (induction xs) (auto simp: set_ins)

lemma sorted_isort: "sorted (isort xs)"
  by (induction xs) (auto simp: sorted_ins)

lemma "mset (isort xs) = mset xs"
  apply (induction xs)
  apply auto

  oops

lemma mset_ins: "mset (ins x xs) = add_mset x (mset xs)"
  by (induction xs) auto

lemma mset_isort: "mset (isort xs) = mset xs"
  by (induction xs) (auto simp: mset_ins)

theorem isort_correct: "sorted (isort xs) \<and> mset (isort xs) = mset xs"
proof
  show "sorted (isort xs)" by (rule sorted_isort)
next
  show "mset (isort xs) = mset xs" by (rule mset_isort)
qed

definition sort_drop :: "'a::linorder list \<Rightarrow> 'a list" where
  "sort_drop xs = []"

definition sort_keep :: "'a::linorder list \<Rightarrow> 'a list" where
  "sort_keep xs = xs"

lemma "sorted (sort_drop xs)"
  by (simp add: sort_drop_def)

lemma "mset (sort_drop xs) = mset xs"
  quickcheck

  nitpick [card 'a = 2]

  oops

lemma "mset (sort_keep xs) = mset xs"
  by (simp add: sort_keep_def)

lemma "sorted (sort_keep xs)"
  quickcheck
  oops

thm properties_for_sort

datatype 'a btree = Lf | Nd "'a btree" 'a "'a btree"

fun set_of :: "'a btree \<Rightarrow> 'a set" where
  "set_of Lf = {}"
| "set_of (Nd l x r) = set_of l \<union> {x} \<union> set_of r"

thm btree.set

fun isin :: "'a::linorder \<Rightarrow> 'a btree \<Rightarrow> bool" where
  "isin x Lf = False"
| "isin x (Nd l y r) =
     (if x < y then isin x l else if y < x then isin x r else True)"

fun tinsert :: "'a::linorder \<Rightarrow> 'a btree \<Rightarrow> 'a btree" where
  "tinsert x Lf = Nd Lf x Lf"
| "tinsert x (Nd l y r) =
     (if x < y then Nd (tinsert x l) y r
      else if y < x then Nd l y (tinsert x r)
      else Nd l y r)"

definition t0 :: "int btree" where
  "t0 = Nd (Nd (Nd Lf 1 Lf) 2 (Nd Lf 4 Lf)) 5 (Nd Lf 8 (Nd Lf 9 Lf))"

value "set_of t0"
value "isin 4 t0"
value "isin 7 t0"

value "tinsert 6 t0"

value "isin 6 (Nd (Nd Lf 1 (Nd Lf 6 Lf)) 5 (Lf :: int btree))"

fun bst :: "'a::linorder btree \<Rightarrow> bool" where
  "bst Lf = True"
| "bst (Nd l x r) =
     (bst l \<and> bst r \<and> (\<forall>y \<in> set_of l. y < x) \<and> (\<forall>y \<in> set_of r. x < y))"

value "bst t0"
value "bst (Nd (Nd Lf 1 (Nd Lf 6 Lf)) 5 (Lf :: int btree))"

fun bst_local :: "'a::linorder btree \<Rightarrow> bool" where
  "bst_local Lf = True"
| "bst_local (Nd l x r) =
     (bst_local l \<and> bst_local r \<and>
      (case l of Lf \<Rightarrow> True | Nd _ y _ \<Rightarrow> y < x) \<and>
      (case r of Lf \<Rightarrow> True | Nd _ y _ \<Rightarrow> x < y))"

lemma "bst_local t \<Longrightarrow> isin x t = (x \<in> set_of t)"
  quickcheck

  oops

lemma "bst t \<Longrightarrow> bst (tinsert x t)"
  apply (induction t)
  apply auto

  oops

lemma set_of_tinsert: "set_of (tinsert x t) = insert x (set_of t)"
  by (induction t) auto

lemma bst_tinsert: "bst t \<Longrightarrow> bst (tinsert x t)"
  by (induction t) (auto simp: set_of_tinsert)

lemma isin_set_of: "bst t \<Longrightarrow> isin x t = (x \<in> set_of t)"
  by (induction t) auto

lemma "bst t \<Longrightarrow> isin y (tinsert x t) = (y = x \<or> isin y t)"
  by (simp add: bst_tinsert isin_set_of set_of_tinsert)

datatype 'a queue = Queue "'a list" "'a list"

fun list_of :: "'a queue \<Rightarrow> 'a list" where
  "list_of (Queue f b) = f @ rev b"

value "list_of (Queue [1, 2] [4, 3 :: nat])"

definition qempty :: "'a queue" where
  "qempty = Queue [] []"

fun refill :: "'a queue \<Rightarrow> 'a queue" where
  "refill (Queue [] b) = Queue (rev b) []"
| "refill q = q"

fun enq :: "'a \<Rightarrow> 'a queue \<Rightarrow> 'a queue" where
  "enq x (Queue f b) = refill (Queue f (x # b))"

fun deq :: "'a queue \<Rightarrow> 'a queue" where
  "deq (Queue [] b) = Queue [] b"
| "deq (Queue (x # f) b) = refill (Queue f b)"

fun first :: "'a queue \<Rightarrow> 'a" where
  "first (Queue f b) = hd f"

value "enq 5 (Queue [1, 2] [4, 3 :: nat])"
value "deq (Queue [1] [4, 3, 2 :: nat])"

fun qinv :: "'a queue \<Rightarrow> bool" where
  "qinv (Queue f b) = (f = [] \<longrightarrow> b = [])"

lemma list_of_qempty: "list_of qempty = []"
  by (simp add: qempty_def)

lemma "list_of (enq x q) = list_of q @ [x]"
  apply (cases q)
  apply auto

  oops

lemma list_of_refill: "list_of (refill q) = list_of q"
  by (cases q rule: refill.cases) auto

lemma list_of_enq: "list_of (enq x q) = list_of q @ [x]"
  by (cases q) (simp add: list_of_refill)

lemma "list_of (deq q) = tl (list_of q)"
  quickcheck

  oops

lemma list_of_deq:
  assumes "qinv q"
  shows "list_of (deq q) = tl (list_of q)"
proof (cases q)
  case (Queue f b)
  show ?thesis
  proof (cases f)
    case Nil
    with Queue assms have "b = []" by simp
    with Nil Queue show ?thesis by simp
  next
    case (Cons x f')
    with Queue show ?thesis by (simp add: list_of_refill)
  qed
qed

lemma first_correct: "qinv q \<Longrightarrow> list_of q \<noteq> [] \<Longrightarrow> first q = hd (list_of q)"
  by (cases q) auto

lemma qinv_refill: "qinv (refill q)"
  by (cases q rule: refill.cases) auto

lemma qinv_qempty: "qinv qempty"
  by (simp add: qempty_def)

lemma qinv_enq: "qinv (enq x q)"
  by (cases q) (simp add: qinv_refill)

lemma qinv_deq: "qinv q \<Longrightarrow> qinv (deq q)"
  by (cases q rule: deq.cases) (auto simp: qinv_refill)

definition tempty :: "'a btree" where
  "tempty = Lf"

export_code isort tempty isin tinsert qempty enq deq first
  in Haskell module_name Verified

fun ins_bad :: "'a::linorder \<Rightarrow> 'a list \<Rightarrow> 'a list" where
  "ins_bad x [] = [x]"
| "ins_bad x (y # ys) = (if x \<le> y then x # ys else y # ins_bad x ys)"

fun isort_bad :: "'a::linorder list \<Rightarrow> 'a list" where
  "isort_bad [] = []"
| "isort_bad (x # xs) = ins_bad x (isort_bad xs)"

fun isempty :: "'a queue \<Rightarrow> bool" where
  "isempty (Queue f b) = (f = [])"

fun inorder :: "'a btree \<Rightarrow> 'a list" where
  "inorder Lf = []"
| "inorder (Nd l x r) = inorder l @ [x] @ inorder r"

fun build :: "'a::linorder list \<Rightarrow> 'a btree" where
  "build [] = Lf"
| "build (x # xs) = tinsert x (build xs)"

definition tsort :: "'a::linorder list \<Rightarrow> 'a list" where
  "tsort xs = inorder (build xs)"

end
