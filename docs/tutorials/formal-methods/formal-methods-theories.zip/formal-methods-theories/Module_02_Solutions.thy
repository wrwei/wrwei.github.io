theory Module_02_Solutions
  imports Module_02
begin

value "A \<longrightarrow> (B \<longrightarrow> (C \<and> D))"

lemma "(A \<longrightarrow> B) \<and> (A \<longrightarrow> C) \<longleftrightarrow> (A \<longrightarrow> B \<and> C)"
  by blast

lemma "(A \<longrightarrow> (B \<longrightarrow> C)) \<longleftrightarrow> (B \<longrightarrow> (A \<longrightarrow> C))"
  by blast

lemma "(\<not> fire \<longrightarrow> (opens \<longrightarrow> badge \<and> pin)) \<longleftrightarrow> (opens \<longrightarrow> badge \<and> pin \<or> fire)"
  by blast

lemma "(warm \<longrightarrow> fast) \<and> \<not> fast \<longrightarrow> \<not> warm"
  by blast

lemma "(ok \<longrightarrow> accepts) \<and> \<not> ok \<longrightarrow> \<not> accepts"
  nitpick
  oops

lemma "(tls \<or> internal) \<and> \<not> internal \<longrightarrow> tls"
  by blast

lemma "(night \<longrightarrow> early) \<and> (early \<longrightarrow> ready) \<and> ready \<longrightarrow> night"
  nitpick
  oops

lemma "(A \<longleftrightarrow> B) \<longleftrightarrow> (\<not> A \<or> B) \<and> (\<not> B \<or> A)"
  by blast

lemma "(A \<longleftrightarrow> B) \<longleftrightarrow> (\<not> A \<and> \<not> B) \<or> (A \<and> B)"
  by blast

lemma "\<not> (A \<or> B \<longrightarrow> C) \<longleftrightarrow> (A \<or> B) \<and> \<not> C"
  by blast

lemma "\<not> (A \<or> B \<longrightarrow> C) \<longleftrightarrow> (A \<and> \<not> C) \<or> (B \<and> \<not> C)"
  by blast

lemma "\<not> ((low \<and> \<not> manual \<longrightarrow> pump) \<and>
         (high \<longrightarrow> \<not> pump) \<and>
         (manual \<longrightarrow> pump))"
  nitpick
  oops

lemma "\<not> ((low \<and> \<not> manual \<longrightarrow> pump) \<and>
         (high \<longrightarrow> \<not> pump) \<and>
         (manual \<longrightarrow> pump) \<and>
         manual \<and> high)"
  by blast

lemma "(low \<and> \<not> manual \<longrightarrow> pump) \<and>
       (high \<longrightarrow> \<not> pump) \<and>
       (manual \<and> \<not> high \<longrightarrow> pump)
       \<longrightarrow> (low \<longrightarrow> pump)"
  nitpick
  oops

lemma "\<not> (low \<and> high) \<and>
       (low \<and> \<not> manual \<longrightarrow> pump) \<and>
       (high \<longrightarrow> \<not> pump) \<and>
       (manual \<and> \<not> high \<longrightarrow> pump)
       \<longrightarrow> (low \<longrightarrow> pump)"
  by blast

lemma "\<not> A \<longleftrightarrow> (A \<longrightarrow> False)"
  by blast

lemma "A \<or> B \<longleftrightarrow> ((A \<longrightarrow> False) \<longrightarrow> B)"
  by blast

lemma "A \<and> B \<longleftrightarrow> ((A \<longrightarrow> B \<longrightarrow> False) \<longrightarrow> False)"
  by blast

lemma "(A \<longleftrightarrow> B) \<longleftrightarrow> (((A \<longrightarrow> B) \<longrightarrow> (B \<longrightarrow> A) \<longrightarrow> False) \<longrightarrow> False)"
  by blast

lemma "\<not> ((p \<longleftrightarrow> \<not> q) \<and> (q \<longleftrightarrow> (p \<longleftrightarrow> q)))"
  nitpick
  oops

lemma "(p \<longleftrightarrow> \<not> q) \<and> (q \<longleftrightarrow> (p \<longleftrightarrow> q)) \<longrightarrow> p \<and> \<not> q"
  by blast

end
