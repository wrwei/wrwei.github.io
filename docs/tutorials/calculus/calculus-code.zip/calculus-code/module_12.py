"""Calculus, Module 12: Applications of integration and improper integrals

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_12.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 12.4: Areas and volumes with SymPy
import sympy as sp
x, y = sp.symbols('x y')
print(sp.solve(sp.Eq(sp.sqrt(x), x**2), x))       # where the curves meet
print(sp.integrate(sp.sqrt(x) - x**2, (x, 0, 1)))  # the area between them
print(sp.pi*sp.integrate(x - x**4, (x, 0, 1)))     # the volume by washers
shells = 2*sp.pi*sp.integrate(x*(x - x**2), (x, 0, 1))
washers = sp.pi*sp.integrate(sp.sqrt(y)**2 - y**2, (y, 0, 1))
print(shells, washers)


# %% Section 12.5: Arc length by computer
import math

def polygon(f, a, b, n):
    """Polygon through n + 1 equally spaced points of y = f(x)."""
    xs = [a + (b - a)*i/n for i in range(n + 1)]
    return sum(math.hypot(xs[i + 1] - xs[i], f(xs[i + 1]) - f(xs[i]))
               for i in range(n))

def simpson(g, a, b, n):
    """Simpson's rule with n subintervals (n even)."""
    h = (b - a)/n
    inner = sum((4 if i % 2 else 2)*g(a + i*h) for i in range(1, n))
    return h/3*(g(a) + inner + g(b))

P = polygon(math.sin, 0, math.pi, 1000)
print(f"polygon, 1000 chords: {P:.10f}")
g = lambda x: math.sqrt(1 + math.cos(x)**2)
for n in [4, 8, 16, 32]:
    print(f"Simpson, n = {n:2d}:     {simpson(g, 0, math.pi, n):.10f}")
import sympy as sp
x = sp.symbols('x')
print(sp.Integral(sp.sqrt(1 + sp.cos(x)**2), (x, 0, sp.pi)).evalf(20))
print(sp.integrate(sp.sqrt(1 + sp.cos(x)**2), x))


# %% Section 12.8: Improper integrals with SymPy
import sympy as sp
x = sp.symbols('x')
print(sp.integrate(1/x**2, (x, 1, sp.oo)))
print(sp.integrate(1/x, (x, 1, sp.oo)))
print(sp.integrate(sp.exp(-x**2), (x, -sp.oo, sp.oo)))
print(sp.integrate(1/x**2, (x, -1, 1)))
F = sp.integrate(1/x**2, x)
print(F, F.subs(x, 1) - F.subs(x, -1))
p = sp.symbols('p', positive=True)
print(sp.integrate(x**(-p), (x, 1, sp.oo)))


# %% Section 12.9: Probabilities by computer
import math
lam = 2.0
print("P(X > 1)         =", math.exp(-lam*1))
print("P(0.5 <= X <= 1) =", math.exp(-lam*0.5) - math.exp(-lam*1))
print("median wait      =", math.log(2)/lam)
print("P(|Z| <= 1.25)   =", math.erf(1.25/math.sqrt(2)))
import random
random.seed(2026)
waits = [-math.log(1 - random.random())/lam for _ in range(100_000)]
long_waits = [w for w in waits if w > 1]
longer = [w for w in long_waits if w > 1.5]
print("mean of the waits:   ", round(sum(waits)/len(waits), 4))
print("fraction over 1 s:   ", round(len(long_waits)/len(waits), 4))
print("of those, over 1.5 s:", round(len(longer)/len(long_waits), 4))
