Calculus: the Python of every module

One script per module (module_NN.py) and one for the exercise solutions (module_NN_solutions.py).
They need Python 3 with SymPy, NumPy and matplotlib:

    python -m pip install sympy numpy matplotlib

Every output shown on the pages was produced by this code.
