"""Calculus, Module 8: The shape of a graph and optimisation

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_08.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 8.1: The closed interval method with SymPy
import sympy as sp
x = sp.symbols('x')
f = 2*x**3 - 3*x**2 - 12*x + 1
crit = sp.solve(sp.diff(f, x), x)       # where f'(x) = 0
print(crit)
for c in [-2] + crit + [3]:             # the critical numbers and the endpoints
    print(c, f.subs(x, c))
g = sp.cbrt(x**2)*(x - 5)
dg = sp.simplify(sp.diff(g, x))
print(dg)
print(sp.solve(dg, x), dg.subs(x, 0))
print(sp.N((x**sp.Rational(2, 3)*(x - 5)).subs(x, -1)), g.subs(x, -1))


# %% Section 8.5: Curve sketching with SymPy
import sympy as sp
x = sp.symbols('x', real=True)
f = x**2/(x**2 - 4)
d1 = sp.factor(sp.diff(f, x))
d2 = sp.factor(sp.diff(f, x, 2))
print(d1)
print(d2)
print(sp.solve(d1, x), sp.solve(d2, x))
print(sp.limit(f, x, sp.oo), sp.limit(f, x, 2, '+'), sp.limit(f, x, 2, '-'))
print(sp.solve(d1 > 0, x))
print(sp.solve(d2 < 0, x))
z = sp.symbols('z')                  # a symbol with no assumptions
print(sp.solve(3*z**2 + 4, z))


# %% Section 8.7: Gradient descent in Python
import math

def df(x):                              # f(x) = x**2/2 + exp(-x)
    return x - math.exp(-x)

def gradient_descent(x, eta, steps):
    xs = [x]
    for _ in range(steps):
        x = x - eta*df(x)
        xs.append(x)
    return xs

for eta in (0.1, 0.6, 1.4):
    xs = gradient_descent(3.0, eta, 7)
    print(f"eta = {eta}:", " ".join(f"{v:.4g}" for v in xs))
def steps_needed(eta, tol=1e-10):
    x, k = 3.0, 0
    while abs(df(x)) > tol and k < 10000:
        x, k = x - eta*df(x), k + 1
    return k

for eta in (0.1, 0.3, 0.6, 1.0, 1.2):
    print(f"eta = {eta}: {steps_needed(eta)} steps")
