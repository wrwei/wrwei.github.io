"""Calculus, Module 19: Multiple integrals

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_19.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 19.2: Double integrals by computer
import sympy as sp
x, y = sp.symbols('x y')
f = 8 - x**2 - y**2
print(sp.integrate(f, (y, 0, 2)))              # the inner integral A(x)
print(sp.integrate(f, (y, 0, 2), (x, 0, 2)))   # y first, then x
print(sp.integrate(x*sp.cos(x*y), (y, 0, 1), (x, 0, sp.pi)))
import numpy as np

def midpoint2d(f, a, b, c, d, n):
    dx, dy = (b - a)/n, (d - c)/n
    xs = a + (np.arange(n) + 0.5)*dx        # centres of the subintervals of [a, b]
    ys = c + (np.arange(n) + 0.5)*dy
    X, Y = np.meshgrid(xs, ys)              # all n*n centres (x_i, y_j)
    return np.sum(f(X, Y))*dx*dy

for n in [2, 10, 100, 1000]:
    print(n, midpoint2d(lambda x, y: 8 - x**2 - y**2, 0, 2, 0, 2, n))


# %% Section 19.3: Reversing the order by computer
import sympy as sp
x, y = sp.symbols('x y')
inner = sp.integrate(sp.exp(y**2), (y, x, 1))
print(inner)
print(sp.simplify(sp.integrate(inner, (x, 0, 1))))
print(sp.integrate(sp.exp(y**2), (x, 0, y), (y, 0, 1)))   # reversed: x first


# %% Section 19.5: Probabilities by simulation
import numpy as np
rng = np.random.default_rng(2026)
N = 1_000_000
X = rng.exponential(scale=1.0, size=N)     # rate 1
Y = rng.exponential(scale=0.5, size=N)     # rate 2
print(np.mean(Y < X))                      # the fraction of trials with Y < X


# %% Section 19.7: Coordinates and their volume elements
import sympy as sp
r, rho = sp.symbols('r rho', nonnegative=True)
theta, z, phi = sp.symbols('theta z phi', real=True)
polar = sp.Matrix([r*sp.cos(theta), r*sp.sin(theta)])
cyl = sp.Matrix([r*sp.cos(theta), r*sp.sin(theta), z])
sph = sp.Matrix([rho*sp.sin(phi)*sp.cos(theta),
                 rho*sp.sin(phi)*sp.sin(theta),
                 rho*sp.cos(phi)])
print(sp.simplify(polar.jacobian([r, theta]).det()))
print(sp.simplify(cyl.jacobian([r, theta, z]).det()))
print(sp.simplify(sph.jacobian([rho, phi, theta]).det()))
J = rho**2*sp.sin(phi)
a = sp.symbols('a', positive=True)
print(sp.integrate(J, (rho, 0, a), (theta, 0, 2*sp.pi), (phi, 0, sp.pi)))
print(sp.integrate(J, (rho, 0, a), (theta, 0, 2*sp.pi), (phi, 0, sp.pi/3)))
