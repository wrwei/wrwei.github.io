"""Calculus, Module 7: Rates, approximation and L'Hôpital's rule

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_07.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 7.1: Related rates with SymPy
import sympy as sp
t = sp.symbols('t')
x = sp.Function('x')(t)          # the foot's distance from the wall at time t
y = sp.Function('y')(t)          # the height of the top
link = x**2 + y**2 - 25          # zero at every instant
dlink = sp.diff(link, t)
print(dlink)
dydt = sp.solve(dlink, sp.Derivative(y, t))[0]
print(dydt)
print(dydt.subs(sp.Derivative(x, t), sp.Rational(1, 2)).subs({x: 3, y: 4}))
print(dydt.subs({x: 3, y: 4}))


# %% Section 7.4: Newton's method in Python
import math

def newton(f, df, x, steps):
    for n in range(1, steps + 1):
        x = x - f(x)/df(x)
        print(f"x{n} = {x:.16f}   f(x{n}) = {f(x):.1e}")
    return x

f = lambda x: math.cos(x) - x
df = lambda x: -math.sin(x) - 1
root = newton(f, df, 1.0, 5)
def my_sqrt(a):
    x = max(a, 1.0)               # a starting value above sqrt(a)
    steps = 0
    while True:
        new = (x + a/x)/2
        steps += 1
        if new >= x:              # no longer decreasing: as good as it gets
            return x, steps
        x = new

for a in [2.0, 3.0, 1e6]:
    print(a, my_sqrt(a), math.sqrt(a))


# %% Section 7.6: Limits with SymPy, and indeterminate forms in floating point
import sympy as sp
x = sp.symbols('x')
print(sp.limit((sp.exp(2*x) - 1)/sp.sin(3*x), x, 0, '+-'))
print(sp.limit((sp.exp(x) - 1 - x)/x**2, x, 0, '+-'))
print(sp.limit(x*sp.log(x), x, 0, '+'))
print(sp.limit(x/(x - 1) - 1/sp.log(x), x, 1, '+-'))
print(sp.limit((1 + 1/x)**x, x, sp.oo))
import math
inf = math.inf
print(0.0*inf, inf - inf, inf/inf)
print(0.0**0.0, 1.0**inf, inf**0.0)
for n in [10, 10**6, 10**12, 10**15, 10**16]:
    print(n, (1 + 1/n)**n)
n = 10**15
print(math.exp(n*math.log1p(1/n)), math.e)
