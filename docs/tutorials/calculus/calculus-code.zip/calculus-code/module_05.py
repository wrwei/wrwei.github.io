"""Calculus, Module 5: Rules of differentiation

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_05.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 5.7: Differentiating with SymPy
import sympy as sp
x = sp.symbols('x')
y = x**3*(2*x - 1)**4            # Example 5.12
dy = sp.diff(y, x)
print(dy)
print(sp.factor(dy))
print(sp.expand(dy))
f, g = sp.Function('f'), sp.Function('g')
print(sp.diff(f(x)*g(x), x))
print(sp.diff(f(g(x)), x))
print(sp.diff(sp.tan(x), x))


# %% Section 5.7: Is my answer right?
import sympy as sp
x = sp.symbols('x')
theirs = sp.diff(sp.sin(x)/(1 + sp.cos(x)), x)     # Example 5.13
mine = 1/(1 + sp.cos(x))
print(theirs)
print(sp.simplify(theirs - mine))
wrong = sp.cos(x**2)
gap = sp.simplify(sp.diff(sp.sin(x**2), x) - wrong)
print(gap)
print([round(float(gap.subs(x, v)), 4) for v in (0.5, 1, 2)])


# %% Section 5.8: Dual numbers in Python
class Dual:
    """A dual number a + b·ε, where ε² = 0."""
    def __init__(self, a, b=0.0):
        self.a, self.b = a, b              # the value and the ε-part
    def __add__(self, other):
        other = other if isinstance(other, Dual) else Dual(other)
        return Dual(self.a + other.a, self.b + other.b)
    def __mul__(self, other):
        other = other if isinstance(other, Dual) else Dual(other)
        return Dual(self.a*other.a, self.a*other.b + self.b*other.a)
    __radd__ = __add__                     # 1 + d and 3*d: number first
    __rmul__ = __mul__
def f(x):
    return x*x*x + (-2)*x + 1          # x³ − 2x + 1, with + and * only

y = f(Dual(1.5, 1.0))
print(y.a, y.b)                        # f(1.5) and f'(1.5)
for h in [1e-1, 1e-4, 1e-8, 1e-12]:
    print(f"h = {h:g}: {(f(1.5 + h) - f(1.5))/h}")
import sympy as sp
x = sp.symbols('x')
fp = sp.diff(x**3 - 2*x + 1, x)
print(fp, '|', fp.subs(x, 1.5))
import math
def sin(d):                            # sin(a + bε) = sin a + (cos a)·b ε
    return Dual(math.sin(d.a), math.cos(d.a)*d.b)

t = Dual(1.0, 1.0)
print(sin(t*t).b, 2*math.cos(1.0))
def g(x):
    y = x
    for _ in range(3):                 # three times: y becomes y² + x
        y = y*y + x
    return y

print(g(Dual(0.5, 1.0)).b)
print(sp.diff(g(x), x).subs(x, sp.Rational(1, 2)))
