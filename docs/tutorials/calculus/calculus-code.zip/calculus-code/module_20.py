"""Calculus, Module 20: Vector calculus

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_20.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 20.2: Line integrals with SymPy
import sympy as sp
x, y, t = sp.symbols('x y t')
F = sp.Matrix([-y, x])

def work(F, path, a, b):
    """The line integral of F along the path (x(t), y(t)), a <= t <= b."""
    r = sp.Matrix(path)
    on_path = F.subs({x: r[0], y: r[1]}, simultaneous=True)
    return sp.integrate(on_path.dot(r.diff(t)), (t, a, b))

print(work(F, [t, t], 0, 1), work(F, [t, t**2], 0, 1))
print(work(F, [t, 0], 0, 1) + work(F, [1, t], 0, 1))
print(work(F, [1 - t, (1 - t)**2], 0, 1))
r = sp.Matrix([sp.cos(t), sp.sin(t)])
speed = sp.sqrt(r.diff(t).dot(r.diff(t)))
print(speed, sp.simplify(speed))
M = sp.integrate((1 + r[1])*sp.simplify(speed), (t, 0, sp.pi))
print(M, sp.N(M, 4))
import numpy as np
import matplotlib.pyplot as plt
X, Y = np.meshgrid(np.linspace(-0.2, 1.2, 8), np.linspace(-0.2, 1.2, 8))
plt.quiver(X, Y, -Y, X, color='grey')            # the field <-y, x>
s = np.linspace(0, 1, 100)
plt.plot(s, s, s, s**2, [0, 1, 1], [0, 0, 1])   # the three paths
plt.gca().set_aspect('equal')
plt.show()


# %% Section 20.4: Areas from corners
import math

def area(corners):
    """The signed area of a simple polygon, with corners in boundary order."""
    n = len(corners)
    total = 0
    for k in range(n):
        x1, y1 = corners[k]
        x2, y2 = corners[(k + 1) % n]    # next corner; wraps round to the first
        total += x1*y2 - x2*y1
    return total/2

print(area([(0, 0), (2, 0), (2, 1), (0, 1)]))
print(area([(0, 0), (0, 1), (2, 1), (2, 0)]))
print(area([(0, 0), (4, 0), (4, 3), (2, 1), (0, 3)]))
for n in [6, 100, 10000]:
    step = 2*math.pi/n          # angle between neighbouring corners
    corners = [(math.cos(k*step), math.sin(k*step)) for k in range(n)]
    print(f"{n} {area(corners):.10f}")
print(f"{math.pi:.10f}")


# %% Section 20.5: Curl and divergence with SymPy
import sympy as sp
from sympy.vector import CoordSys3D, curl, divergence, gradient
N = CoordSys3D('N')
x, y, z = N.x, N.y, N.z
F = x*y*N.i + y*z*N.j + z*x*N.k          # Example 20.10
print(curl(F))
print(divergence(F))
print(divergence(curl(F)))
f = x**2*y*sp.sin(z)
print(gradient(f))
print(curl(gradient(f)))
from sympy.vector import is_conservative, scalar_potential
G = 2*x*y*N.i + (x**2 + 2*y*z)*N.j + y**2*N.k
print(is_conservative(G), scalar_potential(G, N))
V = -y/(x**2 + y**2)*N.i + x/(x**2 + y**2)*N.j      # Example 20.6
print(is_conservative(V))


# %% Section 20.7: Both sides with SymPy
import sympy as sp
x, y, z, t, r, th = sp.symbols('x y z t r theta')

def at(e, p):
    """e (an expression or a Matrix in x, y, z) at the point p."""
    return e.subs({x: p[0], y: p[1], z: p[2]}, simultaneous=True)

def curl(F):
    P, Q, R = F
    return sp.Matrix([sp.diff(R, y) - sp.diff(Q, z),
                      sp.diff(P, z) - sp.diff(R, x),
                      sp.diff(Q, x) - sp.diff(P, y)])

F = sp.Matrix([z, x, y])
edge = sp.Matrix([sp.cos(t), sp.sin(t), 0])
print(sp.integrate(at(F, edge).dot(edge.diff(t)), (t, 0, 2*sp.pi)))
dome = sp.Matrix([r*sp.cos(th), r*sp.sin(th), 1 - r**2])
N = dome.diff(r).cross(dome.diff(th))          # r_r x r_theta
print(sp.simplify(N[2]))
integrand = sp.simplify(at(curl(F), dome).dot(N))
print(sp.integrate(integrand, (r, 0, 1), (th, 0, 2*sp.pi)))
phi, rho = sp.symbols('phi rho')
G = sp.Matrix([x**3, y**3, z**3])
sphere = sp.Matrix([sp.sin(phi)*sp.cos(th), sp.sin(phi)*sp.sin(th),
                    sp.cos(phi)])
N = sphere.diff(phi).cross(sphere.diff(th))    # outwards
flux = sp.integrate(sp.simplify(at(G, sphere).dot(N)),
                    (phi, 0, sp.pi), (th, 0, 2*sp.pi))
divG = sp.diff(G[0], x) + sp.diff(G[1], y) + sp.diff(G[2], z)
dV = rho**2*sp.sin(phi)                         # spherical coordinates
inside = sp.integrate(at(divG, rho*sphere)*dV,
                      (rho, 0, 1), (phi, 0, sp.pi), (th, 0, 2*sp.pi))
print(divG)
print(flux, inside)
