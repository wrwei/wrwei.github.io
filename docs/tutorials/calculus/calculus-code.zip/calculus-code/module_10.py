"""Calculus, Module 10: The Fundamental Theorem of Calculus

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_10.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 10.8: Integrals with SymPy
import sympy as sp
x, t = sp.symbols('x t')
print(sp.integrate(x**2 - 1, x))                     # an antiderivative: no + C
print(sp.integrate(x**2, (x, 0, 1)))                 # a definite integral, exactly
print(sp.integrate(1/(1 + x**2), (x, 0, 1)))         # Example 10.6(d)
print(sp.integrate(2*x*sp.sin(x**2), (x, 0, sp.sqrt(sp.pi))))   # Example 10.12(a)
F = sp.Rational(2, 9)*(x**3 + 1)**sp.Rational(3, 2)   # Example 10.10(b)
print(sp.simplify(sp.diff(F, x) - x**2*sp.sqrt(x**3 + 1)))
I = sp.Integral(sp.exp(-t**2), (t, 0, x**2))
print(sp.diff(I, x))                                 # Example 10.5(b)
print(sp.diff(sp.Integral(1/t, (t, x, 2*x)), x))     # Example 10.5(c)
print(sp.Integral(x**2, (x, 0, 1)).doit())
print(sp.integrate(1/x**2, (x, -1, 1)))


# %% Section 10.8: Answers that differ by a constant
import sympy as sp
x = sp.symbols('x')
mine = (x**2 + 1)**4/4                               # Example 10.10(a), by substitution
theirs = sp.integrate(2*x*(x**2 + 1)**3, x)
print(theirs)
print(sp.expand(mine - theirs))
print(sp.integrate(sp.sin(x)*sp.cos(x), x))
print(sp.simplify(sp.sin(x)**2/2 - (-sp.cos(x)**2/2)))
print(sp.integrate(1/x, x))
print(sp.integrate(1/x, (x, -2, -1)))


# %% Section 10.8: Integrals with special functions
import sympy as sp
x = sp.symbols('x')
print(sp.integrate(sp.exp(-x**2), x))
print(sp.diff(sp.erf(x), x))
I = sp.integrate(sp.exp(-x**2), (x, 0, 1))
print(I, sp.N(I))
import numpy as np
n = 1000
mids = (np.arange(n) + 0.5)/n                        # midpoints of [0, 1] cut into n pieces
print(np.sum(np.exp(-mids**2))/n)
print(sp.integrate(sp.sin(x)/x, x))
