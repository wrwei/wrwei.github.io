"""Calculus, Module 14: Sequences and series

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_14.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 14.2: Sequences in Python and SymPy
import math
a = 1.0
for n in range(1, 9):
    print(f"a_{n} = {a:.10f}   2 - a_{n} = {2 - a:.3e}")
    a = math.sqrt(2 + a)        # the next term
import sympy as sp
n = sp.symbols('n')
print(sp.limit((2*n**2 - 3*n)/(5*n**2 + 4), n, sp.oo))
print(sp.limit(n**(1/n), n, sp.oo), sp.limit((1 + 2/n)**n, n, sp.oo))
print(sp.limit(sp.sin(sp.pi*n), n, sp.oo))
k = sp.symbols('k', integer=True)
print(sp.sin(sp.pi*k))


# %% Section 14.3: Sums with SymPy
import sympy as sp
n, N = sp.symbols('n N', integer=True, positive=True)
print(sp.summation(1/(n*(n + 1)), (n, 1, N)))       # the partial sum S_N
print(sp.summation(1/(n*(n + 1)), (n, 1, sp.oo)))   # the sum
print(sp.apart(1/(n*(n + 2)), n))                   # partial fractions
print(sp.summation(3*sp.Rational(-2, 3)**n, (n, 1, sp.oo)))
r = sp.symbols('r')
print(sp.summation(r**n, (n, 0, sp.oo)))
print(sp.summation(1/(2*n**2 - n), (n, 1, sp.oo)))
s = sum(1/(2*k**2 - k) for k in range(1, 10**6 + 1))   # 10^6 terms
print(f"{s:.6f}  {float(2*sp.log(2)):.6f}")


# %% Section 14.5: How slowly series converge
import math
gamma = 0.5772156649015329            # Euler's constant
H = S = 0.0
n = 0
for N in [10, 100, 1000, 10**4, 10**5, 10**6]:
    while n < N:
        n += 1
        H += 1/n                      # the harmonic series
        S += 1/n**2                   # the series of 1/n^2
    L = math.log(N) + gamma
    print(f"N = {N:>7}:  H_N = {H:9.6f}   ln N + gamma = {L:9.6f}"
          f"   pi^2/6 - S_N = {math.pi**2/6 - S:.3e}")
H, n = 0.0, 0
while H <= 10:
    n += 1
    H += 1/n
print(n, H)
