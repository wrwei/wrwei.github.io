"""Calculus, Module 9: Area and the definite integral

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_09.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 9.2: Sums with Python and SymPy
print(sum(range(1, 101)))                # 1 + 2 + ... + 100
print(sum(i**2 for i in range(1, 11)))   # 1 + 4 + ... + 100
print(sum(range(1, 100)))                # stops at 99
import sympy as sp
i, n = sp.symbols('i n', integer=True, positive=True)
S2 = sp.summation(i**2, (i, 1, n))
print(S2)
print(sp.factor(S2))
print(sp.factor(sp.summation(i**3, (i, 1, n))))
print(sp.summation(2*i - 1, (i, 1, n)))


# %% Section 9.3: Riemann sums in Python
def riemann(f, a, b, n, rule):
    dx = (b - a)/n
    shift = {'left': 0, 'right': 1, 'mid': 0.5}[rule]
    return sum(f(a + (i + shift)*dx) for i in range(n))*dx

def f(x):
    return 1/x

for rule in ['left', 'right', 'mid']:
    print(rule, riemann(f, 1, 2, 4, rule))
import math
prev = None
for n in [10, 20, 40, 80]:
    err = math.log(2) - riemann(f, 1, 2, n, 'mid')
    note = '' if prev is None else f'   previous/this = {prev/err:.3f}'
    print(f'n = {n:2d}   error = {err:.3e}{note}')
    prev = err


# %% Section 9.4: Limits of Riemann sums with SymPy
import sympy as sp
i, n = sp.symbols('i n', integer=True, positive=True)
a, b = 1, 3
dx = sp.Integer(b - a)/n
xi = a + i*dx                         # the right ends
Rn = sp.summation(xi**2*dx, (i, 1, n))
print(sp.factor(Rn))
print(sp.limit(Rn, n, sp.oo))


# %% Section 9.5: A number with no formula yet
import math

def midpoint(f, a, b, n):
    dx = (b - a)/n
    return sum(f(a + (i + 0.5)*dx) for i in range(n))*dx

def g(x):
    return math.exp(-x**2)

for n in [2, 10, 100, 1000]:
    print(f"{n} {midpoint(g, 0, 1, n):.9f}")
