"""Calculus, Module 13: Differential equations

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_13.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 13.4: Euler's method and RK4 in Python
import math

def euler(F, t, y, h, n):
    """n steps of Euler's method from (t, y) with step h; returns the last y."""
    for _ in range(n):
        y, t = y + h*F(t, y), t + h
    return y

F = lambda t, y: t - y                 # y' = t - y, y(0) = 1
exact = 1 + 2*math.exp(-2)             # y(2), from Example 13.1
for n in [10, 20, 40, 80]:
    h = 2/n
    err = exact - euler(F, 0, 1, h, n)
    print(f"h = {h:<6} error = {err:.6f}   error/h = {err/h:.4f}")
def rk4(F, t, y, h, n):
    """n steps of the classical Runge-Kutta method; returns the last y."""
    for _ in range(n):
        k1 = F(t, y)
        k2 = F(t + h/2, y + h/2*k1)
        k3 = F(t + h/2, y + h/2*k2)
        k4 = F(t + h, y + h*k3)
        y, t = y + h/6*(k1 + 2*k2 + 2*k3 + k4), t + h
    return y

for n in [10, 20, 40]:
    h = 2/n
    e1, e4 = exact - euler(F, 0, 1, h, n), exact - rk4(F, 0, 1, h, n)
    print(f"h = {h:<5} Euler error = {e1:.2e}   RK4 error = {e4:.2e}")


# %% Section 13.9: Exact solutions with dsolve
import sympy as sp
t = sp.symbols('t')
y = sp.Function('y')                   # an unknown function of t
ode = sp.Eq(y(t).diff(t), t - y(t))    # y' = t - y
print(sp.dsolve(ode))
sol = sp.dsolve(ode, ics={y(0): 1})    # with the initial condition y(0) = 1
print(sol)
print(sp.checkodesol(ode, sol))
logistic = sp.Eq(y(t).diff(t), y(t)*(1 - y(t)))
print(sp.dsolve(logistic, ics={y(0): sp.Rational(1, 10)}))
x = sp.Function('x')
spring = sp.Eq(x(t).diff(t, 2) + 2*x(t).diff(t) + 5*x(t), 0)
print(sp.dsolve(spring))
print(sp.dsolve(spring, ics={x(0): 1, x(t).diff(t).subs(t, 0): 0}))


# %% Section 13.9: Numerical solutions
def rk4(F, t, y, h, n):
    """n steps of the classical Runge-Kutta method; returns the last y."""
    for _ in range(n):
        k1 = F(t, y)
        k2 = F(t + h/2, y + h/2*k1)
        k3 = F(t + h/2, y + h/2*k2)
        k4 = F(t + h, y + h*k3)
        y, t = y + h/6*(k1 + 2*k2 + 2*k3 + k4), t + h
    return y

F = lambda t, y: t - y**2
for n in [20, 40, 80]:
    print(f"h = {2/n:<6} y(2) = {rk4(F, 0.0, 0.0, 2/n, n):.10f}")
import numpy as np
G = lambda t, u: np.array([u[1], -2*u[1] - 5*u[0]])   # (x, v) -> (x', v')
u = rk4(G, 0.0, np.array([1.0, 0.0]), 0.01, 300)     # 300 steps, to t = 3
exact = np.exp(-3)*(np.cos(6) + np.sin(6)/2)          # Example 13.13, t = 3
print(f"RK4: x(3) = {u[0]:.10f}   exact: {exact:.10f}")
