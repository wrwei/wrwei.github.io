"""Calculus, Module 3: Continuity and infinity

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_03.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 3.4: The bisection method in Python
def bisection(f, a, b, n):
    """n steps of the bisection method on [a, b]; returns the last bracket."""
    if f(a) * f(b) >= 0:
        raise ValueError("f(a) and f(b) must have opposite signs")
    for _ in range(n):
        m = (a + b) / 2
        if f(m) == 0:
            return m, m                    # an exact root
        if (f(m) > 0) == (f(a) > 0):       # same sign as f(a): keep [m, b]
            a = m
        else:                              # otherwise keep [a, m]
            b = m
    return a, b

print(bisection(lambda x: x**2 - 2, 1, 2, 6))
import math
a, b = bisection(lambda x: x**2 - 2, 1, 2, 19)
m = (a + b) / 2
print(m, abs(m - math.sqrt(2)), 2**-20)
a, b = bisection(lambda x: x**3 - 2*x - 5, 2, 3, 30)
print((a + b) / 2)
a, b = bisection(lambda x: math.cos(x) - x, 0, 1, 30)
print((a + b) / 2)
a, b = bisection(lambda x: x**2 - 2, 1, 2, 60)
print(a, b, b - a)


# %% Section 3.7: Asymptotes and continuity with SymPy
import sympy as sp
x = sp.symbols('x')
f = sp.sqrt(4*x**2 + 1)/(x - 3)
print(sp.limit(f, x, sp.oo), sp.limit(f, x, -sp.oo))
print(sp.limit(f, x, 3, '+'), sp.limit(f, x, 3, '-'))
from sympy.calculus.util import continuous_domain
r = (x**2 - 4)/(x**2 - x - 2)
print(continuous_domain(r, x, sp.S.Reals))
q, s = sp.div(x**2 + 1, x - 1)                  # Example 3.13
print(q, s)
print(sp.limit((x**2 + 1)/(x - 1) - q, x, sp.oo))


# %% Section 3.8: Growth rates with exact integers
n = 2
while n**10 >= 2**n:          # exact integer arithmetic: no rounding
    n += 1
print(n, n**10, 2**n)
import math
speed = 10**9                         # steps per second (hypothetical)
year = 365.25 * 24 * 3600             # seconds in a year
for n in (20, 50, 100):
    for name, steps in (("n^2", n**2), ("2^n", 2**n), ("n!", math.factorial(n))):
        seconds = steps / speed
        print(f"n = {n:3}  {name:>3}: {seconds:9.3g} s = {seconds / year:9.3g} years")
