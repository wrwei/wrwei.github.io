"""Calculus, Module 5: Rules of differentiation (exercise solutions)

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_05_solutions.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Exercise 5.8: Same derivative, different looks
import sympy as sp
x = sp.symbols('x')
a = sp.diff(sp.tan(x)**2, x)
b = sp.diff(sp.sec(x)**2, x)
print(a, '|', b)
print(sp.simplify(a - b))


# %% Exercise 5.12: Dividing dual numbers
class Dual:
    def __init__(self, a, b=0.0):
        self.a, self.b = a, b
    def __add__(self, other):
        other = other if isinstance(other, Dual) else Dual(other)
        return Dual(self.a + other.a, self.b + other.b)
    def __mul__(self, other):
        other = other if isinstance(other, Dual) else Dual(other)
        return Dual(self.a*other.a, self.a*other.b + self.b*other.a)
    def __truediv__(self, other):            # (a + bε)/(c + dε), with c ≠ 0
        other = other if isinstance(other, Dual) else Dual(other)
        a, b, c, d = self.a, self.b, other.a, other.b
        return Dual(a/c, (b*c - a*d)/c**2)
    def __rtruediv__(self, other):           # number / dual
        return Dual(other)/self
    __radd__, __rmul__ = __add__, __mul__
def f(x):
    return 1/(1 + x*x)

y = f(Dual(2.0, 1.0))
print(y.a, y.b)
