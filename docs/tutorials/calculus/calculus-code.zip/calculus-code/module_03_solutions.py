"""Calculus, Module 3: Continuity and infinity (exercise solutions)

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_03_solutions.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Exercise 3.7: Limits at infinity
import math
for x in (1e4, 1e8, 1e16):
    print(x, math.sqrt(x*x + x) - x, 1/(math.sqrt(1 + 1/x) + 1))
