"""Calculus, Module 1: Functions and change

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_01.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 1.7: Symbols, substitution, factoring and expanding
import sympy as sp
x = sp.symbols('x')            # x is now a symbol, a name for a number
p = x**3 - x**2 - 6*x          # ** is a power; write * for every product
print(p.subs(x, 4))            # substitute 4 for x: p(4)
print(sp.factor(p))
print(sp.expand((x + 2)*(x - 3)))
r = (x**2 - 4)/(x**2 - x - 2)
print(sp.simplify(r))
print(r.subs(x, 2))


# %% Section 1.7: Exact numbers and decimals
import sympy as sp
t, h = sp.symbols('t h')
s = sp.Rational(49, 10)*t**2                 # 4.9 t^2, with 4.9 kept exact
q = (s.subs(t, 1 + h) - s.subs(t, 1))/h      # the difference quotient at t = 1
print(q)
print(sp.simplify(q))
print(sp.sqrt(8), sp.N(sp.sqrt(8)))
print(sp.N(sp.E), sp.N(sp.pi, 30))
print(sp.N(3*sp.log(10)/sp.log(2), 4))       # Example 1.7; log is ln


# %% Section 1.7: Python's own arithmetic: radians, rounding and domains
import math
print(math.sin(math.pi/6))           # sin(pi/6) is exactly 1/2
print(math.sin(30))                  # 30 radians, not 30 degrees
print(math.sin(math.radians(30)))    # convert 30 degrees to radians first
print(math.log(math.e**2), math.log10(1000))
print((-8)**(1/3))
print(math.cbrt(-8))
import sympy as sp
print(sp.root(-8, 3), sp.real_root(-8, 3))


# %% Section 1.7: Numbers and pictures: lambdify, NumPy and matplotlib
import sympy as sp
import numpy as np
t = sp.symbols('t')
s = sp.lambdify(t, 4.9*t**2)       # the formula as a numerical function
ts = np.linspace(0, 3, 7)          # 7 equally spaced times from 0 to 3
print(ts)
print(s(ts))                       # s at all seven times at once
for h in [0.1, 0.01, 0.001]:
    print(h, (s(1 + h) - s(1))/h)
import matplotlib.pyplot as plt
ts = np.linspace(0, 3, 200)
plt.plot(ts, s(ts))
plt.xlabel('t (seconds)')
plt.ylabel('distance fallen (metres)')
plt.show()
