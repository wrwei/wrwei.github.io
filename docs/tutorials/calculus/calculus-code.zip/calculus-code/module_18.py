"""Calculus, Module 18: Optimisation in several variables

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_18.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 18.2: Classifying critical points with SymPy
import sympy as sp
x, y = sp.symbols('x y', real=True)
f = x**3 + y**3 - 3*x*y
crit = sp.solve([sp.diff(f, x), sp.diff(f, y)], [x, y], dict=True)
H = sp.hessian(f, (x, y))
print(crit)
print(H, ' D =', H.det())
def classify(D, fxx):
    if D > 0:
        return 'local minimum' if fxx > 0 else 'local maximum'
    if D < 0:
        return 'saddle point'
    return 'inconclusive'

for p in crit:
    D, fxx = H.det().subs(p), H[0, 0].subs(p)
    print(p, ' D =', D, ' f_xx =', fxx, ':', classify(D, fxx), ' f =', f.subs(p))
u, v = sp.symbols('u v')                  # no assumptions
g = u**3 + v**3 - 3*u*v
print(len(sp.solve([sp.diff(g, u), sp.diff(g, v)], [u, v], dict=True)), 'solutions')


# %% Section 18.4: Lagrange systems with SymPy
import sympy as sp
x, y, z = sp.symbols('x y z', positive=True)
lam = sp.symbols('lambda', real=True)
V = x*y*z                                   # the open box of Example 18.7
g = x*y + 2*x*z + 2*y*z
eqs = [sp.diff(V, s) - lam*sp.diff(g, s) for s in (x, y, z)] + [g - 300]
print(sp.solve(eqs, [x, y, z, lam], dict=True))
x, y, z, lam, mu = sp.symbols('x y z lambda mu', real=True)
f, g, h = z, x + y + z, x**2 + y**2 + z**2   # Example 18.8
eqs = [sp.diff(f, s) - lam*sp.diff(g, s) - mu*sp.diff(h, s) for s in (x, y, z)]
eqs += [g, h - 6]
for sol in sp.solve(eqs, [x, y, z, lam, mu], dict=True):
    print(sol, ' f =', f.subs(sol))


# %% Section 18.5: Least squares with NumPy
import numpy as np
xs = np.array([0, 1, 2, 3, 4])
ys = np.array([1, 4, 3, 6, 6])
n = len(xs)
A = np.array([[np.sum(xs**2), np.sum(xs)],
              [np.sum(xs),    n]])
rhs = np.array([np.sum(xs*ys), np.sum(ys)])
m, b = np.linalg.solve(A, rhs)               # the normal equations
print(f"normal equations: m = {m:.4f}, b = {b:.4f}")
print("np.polyfit:", np.polyfit(xs, ys, 1))
e = ys - (m*xs + b)
print("residuals:", np.round(e, 4), " E =", round(float(np.sum(e**2)), 4))


# %% Section 18.6: Condition number and steps
import math

def steps_needed(kappa, max_steps=100000):
    if not math.isfinite(kappa) or kappa < 1:
        raise ValueError("kappa must be finite and at least 1")
    eta = 2/(1 + kappa)                         # the best fixed step
    x, y = 1.0, 1.0
    for k in range(max_steps + 1):
        if math.hypot(x, y) <= 1e-6*math.sqrt(2):
            return k                           # completed updates
        if k == max_steps:
            break
        x, y = x - eta*x, y - eta*kappa*y
    raise RuntimeError("distance tolerance not reached within the step limit")

for kappa in (1, 10, 100, 1000):
    print(f"kappa = {kappa:4}   steps needed: {steps_needed(kappa)}")
import numpy as np
xs = np.array([0, 1, 2, 3, 4.0])
ys = np.array([1, 4, 3, 6, 6.0])

def fit_by_descent(xs, ys, eta=0.025, max_steps=100000):
    m = b = 0.0
    for k in range(max_steps + 1):
        e = ys - (m*xs + b)                       # the residuals
        Em, Eb = -2*np.sum(xs*e), -2*np.sum(e)    # the partial derivatives of E
        if not np.isfinite([Em, Eb]).all():
            raise RuntimeError("nonfinite gradient; try a smaller step")
        if max(abs(Em), abs(Eb)) < 1e-6:
            return k, m, b                       # completed updates
        if k == max_steps:
            break
        m, b = m - eta*Em, b - eta*Eb
    raise RuntimeError("gradient tolerance not reached within the step limit")

for name, x in (("raw", xs), ("centred", xs - 2)):
    k, m, b = fit_by_descent(x, ys)
    print(f"{name:8} inputs: {k} steps, m = {m:.6f}, b = {b:.6f}")
