"""Calculus, Module 6: Exponentials, logarithms and implicit differentiation

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_06.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 6.1: Hunting for e
import math
def slope_at_0(a, h=1e-6):
    return (a**h - a**(-h))/(2*h)      # central difference at x = 0
for a in [2, 2.5, 2.7, 2.72, 2.8, 3]:
    print(f"a = {a}: slope at 0 ≈ {slope_at_0(a):.6f}")
lo, hi = 2.0, 3.0
for step in range(30):
    mid = (lo + hi)/2
    if slope_at_0(mid) < 1:
        lo = mid
    else:
        hi = mid
print(f"e lies between {lo:.10f} and {hi:.10f}")
print(f"math.e is      {math.e:.10f}")
for k in [4, 8, 12, 15, 16]:
    n = 10**k
    print(f"n = 10^{k}: {(1 + 1/n)**n}")


# %% Section 6.6: Derivatives with SymPy
import sympy as sp
x = sp.symbols('x', positive=True)
for f in [2**x, sp.log(x, 10), x**sp.E, x**x, sp.asin(x), sp.tanh(x)]:
    print(f, '  ->  ', sp.diff(f, x))
X, Y = sp.symbols('x y')
slope = sp.idiff(X**3 + Y**3 - 6*X*Y, Y, X)     # dy/dx on the folium of Descartes
print(slope)
print(slope.subs({X: 3, Y: 3}))


# %% Section 6.8: Growth and decay with SymPy
import sympy as sp
t, k, C = sp.symbols('t k C')
y = C*sp.exp(k*t)
print(sp.diff(y, t) - k*y)                    # 0: y' = ky for every t
w = C*t*sp.exp(k*t)
print(sp.simplify(sp.diff(w, t) - k*w))       # not 0: w is not a solution
print(sp.solve(sp.Eq(sp.exp(k*t), 2), t))     # the doubling time
k8 = -sp.log(2)/8
print(sp.N(k8, 4), sp.N(sp.exp(30*k8), 3), sp.N(sp.log(sp.Rational(1, 100))/k8, 4))
