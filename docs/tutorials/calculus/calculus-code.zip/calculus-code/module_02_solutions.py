"""Calculus, Module 2: Limits (exercise solutions)

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_02_solutions.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Exercise 2.11: A formula that fools the computer
import math
for x in [1e-2, 1e-4, 1e-6, 1e-7, 1e-8]:
    direct = (math.sqrt(x**2 + 1) - 1)/x**2
    rationalised = 1/(math.sqrt(x**2 + 1) + 1)
    print(f"x = {x:.0e}:  {direct:.12f}  {rationalised:.12f}")
