"""Calculus, Module 2: Limits

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_02.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 2.8: Testing a δ at many points
import numpy as np

def wins(f, a, L, eps, delta, n=200_000):
    # n points strictly inside (a - delta, a + delta), none of them equal to a
    xs = a + delta*np.linspace(-1, 1, n + 2)[1:-1]
    xs = xs[xs != a]
    return bool(np.all(np.abs(f(xs) - L) < eps))

for delta in [0.1, 0.0825, 0.082, 1/14]:
    print(f"delta = {delta:.4f}: {wins(lambda x: x**2, 3, 9, 0.5, delta)}")


# %% Section 2.8: Cancellation in floating point
def s(t):
    return 4.9*t**2

for h in [1e-3, 1e-6, 1e-9, 1e-12, 1e-15]:
    print(h, (s(1 + h) - s(1))/h)
import math
for k in range(1, 10):
    x = 10.0**(-k)
    direct = (1 - math.cos(x))/x**2
    rearranged = (math.sin(x)/x)**2/(1 + math.cos(x))
    print(f"x = {x:.0e}:  {direct:.12f}  {rearranged:.12f}")
print(math.cos(1e-8), math.cos(1e-8) == 1)


# %% Section 2.8: Limits with SymPy
import sympy as sp
x = sp.symbols('x')
print(sp.limit((x**2 - 1)/(x - 1), x, 1, '+-'))
print(sp.limit((sp.sqrt(x + 9) - 3)/x, x, 0, '+-'))
print(sp.limit(sp.sin(x)/x, x, 0, '+-'))
print(sp.limit((1 - sp.cos(x))/x**2, x, 0, '+-'))
f = sp.Abs(x)/x
print(sp.limit(f, x, 0, '-'), sp.limit(f, x, 0, '+'))
print(sp.limit(f, x, 0))
print(sp.limit(1/x**2, x, 0, '+-'))
print(sp.limit(sp.sin(1/x), x, 0, '+-'))
