"""Calculus, Module 4: The derivative

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_04.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 4.5: Derivatives with SymPy
import sympy as sp
x, h = sp.symbols('x h')
p = 4*x**5 - 3*x**3 + 7*x - 2
dp = sp.diff(p, x)                 # the derivative p'(x)
print(dp)
print(dp.subs(x, 1))               # p'(1): differentiate first, then substitute
q = (p.subs(x, x + h) - p)/h       # the difference quotient
print(sp.limit(q, h, 0, '+-'))     # its two-sided limit: the definition
print(sp.diff(p, x, 2))            # the second derivative (Section 4.6)
print(sp.diff(sp.sqrt(x), x))      # Example 4.5
xr = sp.symbols('x', real=True)
d = sp.diff(sp.Abs(xr), xr)
print(d, d.subs(xr, 0))
print(sp.limit(sp.Abs(h)/h, h, 0, '+'), sp.limit(sp.Abs(h)/h, h, 0, '-'))


# %% Section 4.7: Velocities from measurements
import numpy as np
dt = 0.5
t = np.arange(0, 3.01, dt)            # 0, 0.5, 1, ..., 3
s = 4.9*t**2                          # the measured positions
central = (s[2:] - s[:-2])/(2*dt)     # at t = 0.5, 1, ..., 2.5
print(central)
print(np.gradient(s, dt))
print(9.8*t)                          # the exact velocities


# %% Section 4.7: Rounding error in action
import sys
print(sys.float_info.epsilon)
print(1.0 + 1e-16 == 1.0, 1.0 + 1e-15 == 1.0)
def f(x):
    return x**3

a, exact = 1.0, 3.0
print(f"{'h':>7}  {'forward error':>13}  {'central error':>13}")
for k in range(1, 16):
    h = 10.0**(-k)
    forward = (f(a + h) - f(a))/h
    central = (f(a + h) - f(a - h))/(2*h)
    print(f"{h:7.0e}  {exact - forward:13.2e}  {exact - central:13.2e}")
