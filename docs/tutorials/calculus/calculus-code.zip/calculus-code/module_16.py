"""Calculus, Module 16: Curves and vectors

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_16.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 16.3: Curves with SymPy
import sympy as sp
t = sp.symbols('t')
x, y = t**2, t**3 - 3*t
slope = sp.diff(y, t)/sp.diff(x, t)
print(slope)
print(sp.solve(sp.diff(y, t), t), sp.solve(sp.diff(x, t), t))
print([slope.subs(t, v) for v in (sp.sqrt(3), -sp.sqrt(3))])
r = sp.symbols('r', positive=True)
X, Y = r*(t - sp.sin(t)), r*(1 - sp.cos(t))
speed = sp.sqrt(sp.diff(X, t)**2 + sp.diff(Y, t)**2)
print(sp.simplify(speed))
print(sp.integrate(speed, (t, 0, 2*sp.pi)))
print(sp.integrate(2*r*sp.sin(t/2), (t, 0, 2*sp.pi)))
ellipse = sp.Integral(sp.sqrt(9*sp.sin(t)**2 + 4*sp.cos(t)**2), (t, 0, 2*sp.pi))
print(ellipse.evalf(10))
th = sp.symbols('theta')
print(sp.integrate((1 + sp.cos(th))**2/2, (th, 0, 2*sp.pi)))
print(sp.integrate(sp.cos(3*th)**2/2, (th, -sp.pi/6, sp.pi/6)))


# %% Section 16.7: Vectors with SymPy and NumPy
import sympy as sp
a = sp.Matrix([2, -1, 2])
b = sp.Matrix([1, 3, 0])
print(a.dot(b), a.norm(), b.norm())
print(a.cross(b).T, a.cross(b).norm())
angle = sp.acos(a.dot(b)/(a.norm()*b.norm()))
print(angle, sp.N(angle*180/sp.pi, 6))
P, Q, R = sp.Matrix([1, 0, 1]), sp.Matrix([2, 2, 0]), sp.Matrix([0, 1, 3])
n = (Q - P).cross(R - P)
x, y, z = sp.symbols('x y z')
print(n.T, sp.expand(n.dot(sp.Matrix([x, y, z]) - P)))
S = sp.Matrix([2, 3, 4])
print(sp.Abs(n.dot(S - P))/n.norm())
import numpy as np
a, b = np.array([2, -1, 2]), np.array([1, 3, 0])
print(np.dot(a, b), np.cross(a, b), np.linalg.norm(a))
cos_t = np.dot(a, b)/(np.linalg.norm(a)*np.linalg.norm(b))
print(np.degrees(np.arccos(cos_t)))


# %% Section 16.8: Motion with SymPy
import sympy as sp
t, alpha = sp.symbols('t alpha', positive=True)
g, v0 = sp.Rational(98, 10), 20
a = sp.Matrix([0, -g])                       # the acceleration
v_start = sp.Matrix([v0*sp.cos(alpha), v0*sp.sin(alpha)])
v = v_start + sp.integrate(a, (t, 0, t))
r = sp.integrate(v, (t, 0, t))               # starts at the origin
print(r.T)
t_f = sp.solve(r[1], t)
print(t_f)
R = sp.simplify(r[0].subs(t, t_f[0]))
print(R)
critical = sp.solveset(sp.diff(R, alpha), alpha, domain=sp.Interval(0, sp.pi/2))
best = max([0, sp.pi/2, *critical], key=lambda angle: R.subs(alpha, angle))
print(critical, best, R.subs(alpha, best), sp.N(R.subs(alpha, best), 6))
r = sp.Matrix([sp.cos(t), sp.sin(t), t])
v, a = r.diff(t), r.diff(t, 2)
speed = sp.simplify(v.norm())
print(speed, sp.integrate(speed, (t, 0, 2*sp.pi)))
print(sp.simplify(v.cross(a).norm()/speed**3))
