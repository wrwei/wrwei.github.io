"""Calculus, Module 15: Power series and Taylor series

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_15.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 15.4: Taylor series with SymPy
import sympy as sp
x = sp.symbols('x')
print(sp.series(sp.exp(x), x, 0, 6))
print(sp.series(sp.sin(x), x, 0, 8).removeO())
print(sp.series(sp.sqrt(x), x, 4, 3))
k = sp.symbols('k')
print(sp.series((1 + x)**k, x, 0, 4))
print(sp.series(sp.tan(x), x, 0, 10))
print(sp.series(x**3, x, 4))


# %% Section 15.6: Fifty digits of π
from fractions import Fraction
import sympy as sp

def arctan_sum(x, n):
    """The first n terms of x - x**3/3 + x**5/5 - ..., as an exact fraction."""
    return sum(Fraction((-1)**k, 2*k + 1)*x**(2*k + 1) for k in range(n))

def machin(n):
    """Pi from n terms of each series in Machin's formula."""
    p = 4*(4*arctan_sum(Fraction(1, 5), n) - arctan_sum(Fraction(1, 239), n))
    return sp.Rational(p.numerator, p.denominator)

for n in (2, 5, 10, 20, 36):
    print(f"{n:2d} terms: error {sp.N(sp.pi - machin(n), 2)}")
print(sp.N(machin(36), 52))


# %% Section 15.6: A sine function of your own
import math

S = [(-1)**j/math.factorial(2*j + 1) for j in range(8)]    # sin: r, r^3, ..., r^15
C = [(-1)**j/math.factorial(2*j) for j in range(9)]        # cos: 1, r^2, ..., r^16

def poly(coeffs, u):
    """c0 + c1*u + c2*u**2 + ..., by Horner's rule."""
    total = 0.0
    for c in reversed(coeffs):
        total = total*u + c
    return total

def my_sin(x):
    k = round(x/(math.pi/2))           # x = k*(pi/2) + r with |r| <= pi/4
    r = x - k*(math.pi/2)
    s, c = r*poly(S, r*r), poly(C, r*r)
    return [s, c, -s, -c][k % 4]

for x in [0.5, 2.0, 10.0, 1000.0, 1e6]:
    print(f"x = {x:>9}: my_sin = {my_sin(x):+.16f}, math.sin = {math.sin(x):+.16f}")


# %% Section 15.7: Euler's formula in Python
import cmath
import math
print(1j**2)
print(cmath.exp(1j*math.pi))
theta = 1.0
print(cmath.exp(1j*theta))
print(math.cos(theta), math.sin(theta))
import sympy as sp
t = sp.symbols('t', real=True)
y = sp.Function('y')
print(sp.exp(sp.I*sp.pi))
print(sp.expand(sp.exp(sp.I*t), complex=True))
print(sp.dsolve(y(t).diff(t, 2) + 2*y(t).diff(t) + 10*y(t)))
