"""Calculus, Module 11: Techniques of integration

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_11.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 11.4: Partial fractions with SymPy
import sympy as sp
x = sp.symbols('x')
P = x**3 + 2*x**2 + 2*x - 2
Q = x**2 + x - 2
print(sp.factor(Q))
print(sp.div(P, Q, x))                  # (quotient, remainder)
print(sp.apart(P/Q, x))                 # Example 11.16
print(sp.apart((2*x**2 + 4*x + 4)/((x + 1)*(x**2 + 1)), x))
print(sp.apart(1/(x**2 - 2), x))
print(sp.apart(1/(x**2 - 2), x, extension=sp.sqrt(2)))


# %% Section 11.6: Integrals of this module by computer
import sympy as sp
x = sp.symbols('x')
print(sp.integrate(x**2*sp.sin(x), x))                 # Example 11.3
print(sp.integrate(sp.exp(x)*sp.sin(x), x))            # Example 11.6
print(sp.integrate((5*x - 4)/(x**2 - x - 2), x))       # Example 11.15(a)
print(sp.integrate(1/sp.sqrt(x**2 + 4), x))            # Example 11.14(a)
print(sp.integrate(sp.sec(x), x))                      # Theorem 11.4
mine = sp.log(x + sp.sqrt(x**2 + 4))                   # Example 11.14(a)
print(sp.simplify(sp.diff(mine, x) - 1/sp.sqrt(x**2 + 4)))
print(sp.simplify(sp.diff(sp.log(sp.sec(x) + sp.tan(x)), x) - sp.sec(x)))
print(sp.N((mine - sp.asinh(x/2)).subs(x, 3)), sp.N(sp.log(2)))
print(sp.integrate(sp.sqrt(1 + sp.cos(x)**2), x))


# %% Section 11.6: Special functions in SymPy
import sympy as sp
x = sp.symbols('x')
for f in [sp.exp(-x**2), sp.sin(x)/x, 1/sp.log(x), sp.exp(x)/x]:
    print(sp.integrate(f, x))
print(sp.N(sp.li(2)))
print(sp.primepi(10**6), sp.N(sp.Li(10**6)))
print(sp.Integral(sp.exp(-x**2), (x, 0, 1)).evalf())


# %% Section 11.7: The three rules side by side
import math

def midpoint(f, a, b, n):
    dx = (b - a)/n
    return dx*sum(f(a + (i + 0.5)*dx) for i in range(n))

def trapezoid(f, a, b, n):
    dx = (b - a)/n
    return dx*(f(a)/2 + sum(f(a + i*dx) for i in range(1, n)) + f(b)/2)

def simpson(f, a, b, n):                    # n must be even
    dx = (b - a)/n
    inner = sum((4 if i % 2 else 2)*f(a + i*dx) for i in range(1, n))
    return dx/3*(f(a) + inner + f(b))
f = lambda x: math.exp(-x**2)
exact = math.sqrt(math.pi)/2*math.erf(1)        # the integral from 0 to 1
ns = [4, 8, 16, 32, 64]
rules = {'M': midpoint, 'T': trapezoid, 'S': simpson}
err = {r: [exact - rule(f, 0, 1, n) for n in ns] for r, rule in rules.items()}
print('  n        E_M        E_T        E_S')
for k, n in enumerate(ns):
    print(f'{n:3d}' + ''.join(f'{err[r][k]:11.2e}' for r in rules))
for r in rules:
    print(r, [round(err[r][k - 1]/err[r][k], 2) for k in range(1, len(ns))])
