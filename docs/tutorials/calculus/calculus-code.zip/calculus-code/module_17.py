"""Calculus, Module 17: Partial derivatives and the gradient

The Python of the module page, one cell (# %%) per box, in page order. Run it with
    python module_17.py
or open it in an editor that runs # %% cells (VS Code, Spyder, JupyterLab with jupytext).
"""

# %% Section 17.3: Partial derivatives with SymPy
import sympy as sp
x, y = sp.symbols('x y')
f = x**3*y**2 - 5*x*y + 2*y**3                  # Example 17.5
print(sp.diff(f, x), '|', sp.diff(f, y))
print(sp.diff(f, x, y), '|', sp.diff(f, y, x))  # f_xy and f_yx
print(sp.diff(f, x).subs({x: 1, y: 2}))         # f_x(1, 2)
r, h = sp.symbols('r h', positive=True)
V = sp.pi*r**2*h
print(sp.diff(V, r), '|', sp.diff(V, h))
Vr = sp.diff(V, r).subs({r: 3, h: 10})     # V_r(3, 10)
print(Vr, '=', sp.N(Vr))


# %% Section 17.6: Gradients with SymPy and NumPy
import sympy as sp
x, y = sp.symbols('x y')
f = x*sp.exp(y)
grad = sp.Matrix([sp.diff(f, x), sp.diff(f, y)])
g = grad.subs({x: 2, y: 0})
u = sp.Matrix([3, 4])/5
print(grad.T, '|', g.T, '|', g.dot(u), '|', g.norm())
import numpy as np
gx, gy = 1.0, 2.0                               # grad f(2, 0)
alpha = np.radians(np.arange(0, 360, 0.5))      # the angles of u = <cos a, sin a>
D = gx*np.cos(alpha) + gy*np.sin(alpha)         # D_u f for each direction
k = np.argmax(D)
print(f"largest D_u f: {D[k]:.6f}, at {np.degrees(alpha[k])} degrees")
angle = np.degrees(np.arctan2(gy, gx))           # the direction of grad f
print(f"|grad f| = {np.hypot(gx, gy):.6f}, at {angle:.4f} degrees")


# %% Section 17.7: Gradient descent with NumPy
import numpy as np

def grad(p):                            # f(x, y) = x**2 + 3*y**2
    return np.array([2*p[0], 6*p[1]])

def descent(eta, steps, p=(3.0, 1.0)):
    p = np.array(p)
    for _ in range(steps):
        p = p - eta*grad(p)
    return p

for eta in (0.1, 0.3):
    for k in (1, 2, 5, 10, 20):
        x, y = descent(eta, k)
        print(f"eta = {eta}, k = {k:2d}: ({x:9.6f}, {y:9.6f})")
def steps_needed(eta, tol=1e-8, max_steps=10000):
    p = np.array([3.0, 1.0])
    for k in range(max_steps + 1):
        size = np.linalg.norm(grad(p))
        if size < tol:
            return k
        if size >= 1e6 or k == max_steps:
            return None
        p = p - eta*grad(p)

for eta in (0.05, 0.1, 0.2, 0.25, 0.3, 0.33, 0.34):
    k = steps_needed(eta)
    print(f"eta = {eta}: " + (f"{k} steps" if k is not None else "tolerance not reached"))


# %% Section 17.8: Backpropagation in Python
class Var:
    """A node of a computational graph."""
    def __init__(self, value, parents=()):
        self.value, self.parents, self.grad = value, parents, 0.0
    def __add__(self, other):
        other = other if isinstance(other, Var) else Var(other)
        return Var(self.value + other.value, [(self, 1.0), (other, 1.0)])
    def __mul__(self, other):
        other = other if isinstance(other, Var) else Var(other)
        a, b = self.value, other.value
        return Var(a*b, [(self, b), (other, a)])
    def __sub__(self, other):
        return self + (-1.0)*other
    def __rsub__(self, other):
        return (-1.0)*self + other
    __radd__, __rmul__ = __add__, __mul__
def backward(out):
    order, seen = [], set()
    def visit(v):
        if id(v) not in seen:
            seen.add(id(v))
            for p, _ in v.parents:
                visit(p)
            order.append(v)
    visit(out)
    for v in order:
        v.grad = 0.0
    out.grad = 1.0
    for v in reversed(order):
        for p, local in v.parents:
            p.grad += v.grad*local
data = [(1, 1), (2, 3)]                 # the points (x, t)

def loss(w, b):
    L = 0
    for x, t in data:
        e = t - (w*x + b)               # true value minus prediction
        L = L + e*e
    return L

w, b = Var(0.0), Var(0.0)
L = loss(w, b)
backward(L)
print(L.value, w.grad, b.grad)
import sympy as sp
ws, bs = sp.symbols('w b')
Ls = sum((t - (ws*x + bs))**2 for x, t in data)
print(sp.expand(Ls), '|', [sp.diff(Ls, v).subs({ws: 0, bs: 0}) for v in (ws, bs)])
w, b = Var(0.0), Var(0.0)
for step in range(501):
    L = loss(w, b)
    if step in (0, 1, 2, 10, 100, 500):
        Lv, wv, bv = L.value, w.value, b.value
        print(f"step {step:3d}: L = {Lv:.3g}, w = {wv:.4f}, b = {bv:.4f}")
    if step < 500:
        backward(L)
        w, b = Var(w.value - 0.05*w.grad), Var(b.value - 0.05*b.grad)
