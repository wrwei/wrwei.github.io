Linear Algebra / 线性代数

Run an example with python module_01.py.
Install the dependencies with
    python -m pip install numpy sympy

用 python module_01.py 运行一个示例。
用以下命令安装依赖
    python -m pip install numpy sympy
